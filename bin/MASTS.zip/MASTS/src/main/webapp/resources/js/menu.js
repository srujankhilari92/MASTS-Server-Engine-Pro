  $(document).ready(function() {
 $( "#2" ).click(function() {
				$('#span2').toggleClass("arrow1");
                $( "#sub2" ).slideToggle( "slow");
                return false;
			     });
 $("#3").click(function(){
	    	$("#span3").toggleClass("arrow1");
	        $("#sub3").slideToggle("slow");
	        return false;
});
	$("#nav ul  li a").click(
							function() {
								$("#nav ul li a").removeClass("current")
										.addClass('uncurrent')
								$(this).toggleClass("current uncurrent");
								return false;
							});
		 });
			   