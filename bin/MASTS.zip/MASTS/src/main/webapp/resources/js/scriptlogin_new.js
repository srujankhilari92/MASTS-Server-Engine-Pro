jQuery(document).ready(function($) {
		
 	   alert("ok");
 	   myFunc();
 	   
 	    	
});
  
function myFunc() {
   alert("call");
}