function vali()
{
var $j4 = jQuery.noConflict();
			       $j4('#overlay').fadeIn('fast',function(){
			               $j4('#box').show();
			               $j4('#box').animate({'top':'35%'},500);
			       });
			       valiStopClose();      

}
function vali21(){
var $j5 = jQuery.noConflict();
       $j5('#overlay').fadeOut('fast',function(){
   $j5('#box').hide();
   });
}
function valiStopClose(){
setTimeout(function(){
vali21();
 }, 5000);
}

function vali1()
{
var $j4 = jQuery.noConflict();
			       $j4('#overlay').fadeIn('fast',function(){
			               $j4('#box').show();
			               $j4('#box').animate({'top':'35%'},500);
			       });
			       valiStopClose1();      

}
function vali211(){
var $j5 = jQuery.noConflict();
       $j5('#overlay').fadeOut('fast',function(){
   $j5('#box').hide();
   });
}
function valiStopClose1(){
setTimeout(function(){
vali21();
 }, 300);
}