
var circle = new Sonic({

	
    width: 50,
    height: 50,
    padding: 30,
	
    strokeColor: 'red',

    pointDistance: .01,
    stepsPerFrame: 3,
    trailLength: .7,

    step: 'fader',

    setup: function() {
    	this._.lineWidth = 5;
    },

    path: [
        ['arc', 20, 20, 20, 0, 360]
    ]

});





function stop(){
	alert("Testing has been Completed...");
	circle.stop();
	var load=document.getElementById("load");
	load.setAttribute("style", "display:none");

	}

window.setTimeout(function(){stop()}, 1000*60);

function display(){
	var myvar=setInterval(function play(){
		alert("Testing Started....");
	circle.play();
	var load=document.getElementById("load");
	load.appendChild(circle.canvas);
	});
	
	
	
}

