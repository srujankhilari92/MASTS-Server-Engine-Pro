 $(window).unload(function(){
	  
	  $.ajax({
			type:"POST",
			url:"http://localhost:9091/MASTS/Check",
			async: true,
			cache: false,
			success:function(data){
				
			}
		});
	
  });
