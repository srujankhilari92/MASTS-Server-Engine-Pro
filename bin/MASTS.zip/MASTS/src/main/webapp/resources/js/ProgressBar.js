jQuery.noConflict(); 
jQuery(document).ready(function($){
	//alert('ready');

	$('#display').click(function(){
		//alert('display');
		$('.backdrop, .box').animate({'opacity':'.50'}, 300, 'linear');
		$('.box').animate({'opacity':'1.00'}, 300, 'linear');
		$('.backdrop, .box').css('display', 'block');
	});

	$('.close').click(function(){
		close_box();
	});

	$('.backdrop').click(function(){
		close_box();
	});

	//alert($('#status').attr('title'));
});

jQuery(function($) {

	//alert('progress bar function');
	var progressbar = $( "#progressbar-5" );
	var progressLabel = $( ".progress-label" );
	$( "#progressbar-5" ).progressbar({

		value: false,
		change: function() {
			//alert('123');
			progressLabel.text( 
					progressbar.progressbar( "value" ) + "%" );
		},
		complete: function() {
			progressLabel.text( "Loading Completed! Wait For Processing" );
		}
	});
	 function progress() {
            var val = progressbar.progressbar( "value" ) || 0;
            progressbar.progressbar( "value", val + 1 );
            if ( val < 99 ) {
               setTimeout( progress, 80 );
            }
         }
	setTimeout(progress, 3000 );
});


function monitor(data){
	/*alert('123');
    	alert(data);*/
	
	var loading = document.getElementById("backdrop");
	if(data.status == "begin"){
		//alert(data.status);
		loading.style.display = "block";
	}
	else if(data.status == "success"){
		//alert(data.status);
		loading.style.display = "none";
	}
}