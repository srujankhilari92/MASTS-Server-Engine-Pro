$(document).ready(function() {
	alert("DEMO");
	$("#autheticate").click(function () {
		   $("#authenticatecontent").slideToggle();
		});
});
