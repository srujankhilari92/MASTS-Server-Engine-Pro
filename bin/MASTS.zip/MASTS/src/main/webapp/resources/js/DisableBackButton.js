jQuery.noConflict();
function changeHashOnLoad() {
	//alert(123);
     window.location.href += "#";
     setTimeout("changeHashAgain()", "50"); 
//     PF('poll11').start();
     
}
 
function changeHashAgain() {
  window.location.href += "1";
}
 
var storedHash = window.location.hash;
window.setInterval(function () {
    if (window.location.hash != storedHash) 
    {
         window.location.hash = storedHash;
    }
}, 50);



function reloadURL()
{
    window.location.reload();
}

$(document).ready(function(){
	
	$( ".sub1" ).hide();
	$( ".sub2" ).hide();
	$( ".sub3" ).hide();
	
	$( "#1" ).click(function() {
	$('#span1').toggleClass("arrow1");
	
	$( ".sub1" ).slideToggle( "slow" );
	$( ".sub2" ).slideUp( "slow" );
	$( ".sub3" ).slideUp( "slow" );
	});
	/*$(".sh").click(function() {
		alert('GJHgjh');
		var r=$('.sh').parent().attr('id');

		alert(r);
		//$(".sh").closest(".sc").css("display","none");
	});*/
	
	$(".Automated").click(function(){
		//alert("Automated...");
		
		$(".AutomatedGrid" ).css("display","block");
		$(".PieChart" ).css("display","block");
		
	});
	$(".pieChart").click(function(){
		//alert("Automated...");
		
		$(".PieChart" ).css("display","block");
		
		
	});
	
	
	$(".Preview").click(function(){
		//alert("Preview...");
		$(".PreviewGrid" ).css("display","block");
	});
	
	$(".Assisted").click(function(){
		//alert("Automated...");
		
		$(".AssistedGrid" ).css("display","block");
		
		
	});
	
	
	/*$(".os").click(function(){
		//alert("Preview...");
		$(".osGrid" ).css("display","block");
	});
	$(".hw").click(function(){
		//alert("Preview...");
		$(".hwGrid" ).css("display","block");
	});
	$(".nw").click(function(){
		//alert("Preview...");
		$(".nwGrid" ).css("display","block");
	});
	$(".process").click(function(){
		//alert("Preview...");
		$(".processGrid" ).css("display","block");
	});
	
	$(".app").click(function(){
		//alert("Preview...");
		$(".appGrid" ).css("display","block");
	});
	$(".browser").click(function(){
		//alert("Preview...");
		$(".browserGrid" ).css("display","block");
	});
	$(".history").click(function(){
		//alert("Preview...");
		$(".historyGrid" ).css("display","block");
	});
	$(".port").click(function(){
		//alert("Preview...");
		$(".portGrid" ).css("display","block");
	});
	*/
	});
$(document).ready(function(){
//Click event to scroll to top
	$('.top').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
	
});