jQuery.noConflict();

$(window).bind('setup1', function() {

	function update() {

		$.ajax({
			type:"POST",
			url:"http://"+window.location.host+"/VMastsCDV",
			async: true,
			cache: false,

			success:function(data){

				$.each(data, function( key, val ) {
					if(key=="result" && val=="SUCCESS"){

						$('#deviceForm\\:deviceLabel').css("display","none");
						$('#status').attr('src',"images/online.png");
						$('#status').attr('title',"Connected");
						$('#status').css("display","block");
					}else{

						$('#deviceForm\\:deviceLabel').css("display","block");
						$('#status').attr('src','images/offline.png');
						$('#status').attr('title',"Disconnected");
						$('#status').css("display","block");
						

						valiCloseAll();


					}


				});
			},
			error:function(data){
				
				$('#deviceForm\\:deviceLabel').css("display","block");
				$('#status').attr('src','images/offline.png');
				$('#status').attr('title',"Disconnected");
				$('#status').css("display","block");
				count7();

			}
		});
	}

	setInterval(update, 30000);
	update();
});

$(document).ready(function() {

	$(window).trigger('setup1');	


	$(document).keydown(function (e) {

		return (e.which || e.keyCode) != 116;
	});

	history.pushState({ page: 1 }, "Title 1", "");
	window.onhashchange = function (event) {
		window.location.hash = " ";
	};
});
function reloadURL()
{
	window.location.reload();
}

function valiCloseAll(){
	var $j5 = jQuery.noConflict();
	$j5('#overlay').fadeOut('fast',function(){
		$j5('#box').hide();
	});
}