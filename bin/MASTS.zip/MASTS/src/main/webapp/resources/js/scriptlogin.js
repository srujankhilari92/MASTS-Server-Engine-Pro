        
  jQuery(document).ready(function($){
	   
	 // alert("pattern ok ");
	  patternlock();
	   
   });
  
   function patternlock(){
	   //alert("patten call");
	   
	    var errorraised = false;
		var passwordset = false;
		var getClickStarted = false;
		var autosubmit = true;
		var password;
	    var centerX1;
	    var centerY1;
	    var curX = 0;
	    var curY = 0;
	    var getClickStarted = false;
	    var htmlLine;
	    var startpointnumber=0;
	    var endpointnumber=0;
	    
	    var _gaq = _gaq || [];
	    _gaq.push(['_setAccount', 'UA-36251023-1']);
	    _gaq.push(['_setDomainName', 'jqueryscript.net']);
	    _gaq.push(['_trackPageview']);

	    (function() {
	      var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	      ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	    })();

		(function generatebuttons(){
		
			var patterncontainer  = document.getElementById("patterncontainer");
			for (var i = 1; i <=9; i++) {
				var button = document.createElement("div");
				button.className = "button1";
				button.id = "button1" + i;
				patterncontainer.appendChild(button);

				startposition = document.getElementById("button1" + i);
			}
		}());
		
		(function main(){
		//	if(!window.navigator.msPointerEnabled) {

				$(".button1").on("mousedown", function (event){

					if(!getClickStarted){
						
						getClickStarted = true;

						var offset1 = $("#" + event.target.id).position();

						centerX1 = offset1.left + $("#" + event.target.id).innerWidth()/2 + 20.5; //22.5 is the margin of the button class
						centerY1 = offset1.top + $("#" + event.target.id).innerHeight()/2 + 20.5;

						//console.log("centerX1 " + centerX1);
						//console.log("centerY1 " + centerY1);

						if (event && event.preventDefault){
				               event.preventDefault();
			            }

						$("#" + event.target.id).removeClass("button1").addClass("activebutton1");

						password = event.target.id.split("button1").join("");
						startpointnumber = event.target.id.split("button1").join("");

						//console.log("startpointnumber " + startpointnumber);

						addline(startpointnumber, centerX1, centerY1); //initiating a moving line
					}

				});

				$(document).bind("mousemove", function(event) {
				    if (getClickStarted){ //to avoid mousemove triggering before click

				        if (event && event.preventDefault){
				           event.preventDefault();
				        }

				        curX = event.clientX - $("#patterncontainer").offset().left;
				        curY = event.clientY - $("#patterncontainer").offset().top;

				        var width = Math.sqrt(Math.pow(curX - centerX1, 2) + Math.pow(curY - centerY1, 2)); //varying width and slope
				        var slope = Math.atan2(curY - centerY1, curX - centerX1)*180/3.14;

				        //setting varying width and slope to line
				        $("#line" + startpointnumber).css({"width": + 7 +"px", "height": "4px", "transform": "rotate(" + slope + "deg)", "-webkit-transform": "rotate(" + slope + "deg)", "-moz-transform": "rotate(" + slope + "deg)","-ms-transform":"rotate(" + slope + "deg)"});

				        //if button is found on the path
	    	    		$(".button1").bind("mouseover", function(e) {

	    	    			endpointnumber = e.target.id.split("button1").join("");

	        				if (startpointnumber != endpointnumber) {
								if (e && e.preventDefault){
					               e.preventDefault();
					            }

					            if (e.target.className == "button1") {
					            	$("#" + e.target.id).removeClass("button1").addClass("activebutton1");
					            	  $("#line" + startpointnumber).attr("id", "line" + startpointnumber + endpointnumber);

							            var offset2 = $("#" + e.target.id).position();
							            
							            var centerX2 = offset2.left + $("#" + e.target.id).innerWidth()/2 + 20.5;  //20.5 is the margin of activebutton class
							            var centerY2 = offset2.top + $("#" + e.target.id).innerHeight()/2 + 20.5;

							            var linewidth = Math.sqrt(Math.pow(centerX2 - centerX1, 2) + Math.pow(centerY2 - centerY1, 2));
							            var lineslope = Math.atan2(centerY2 - centerY1, centerX2 - centerX1)*180/3.14;

							            $("#line" + startpointnumber + endpointnumber).css({"width": + linewidth +"px", "transform": "rotate(" + lineslope + "deg)", "-webkit-transform": "rotate(" + lineslope + "deg)", "-moz-transform": "rotate(" + lineslope + "deg)"});

							            startpointnumber = endpointnumber;
							            centerX1 = centerX2;
							            centerY1 = centerY2;

							            addline(startpointnumber, centerX1, centerY1);
								} else {
									//$("#" + e.target.id).removeClass("activebutton").addClass("duplicatebutton");
								}

					            password += e.target.id.split("button1").join("");
					            // endpointnumber = e.target.id.split("button").join("");

					          
	        				}

	    	    		});
				    }

					$("#patterncontainer").on("mouseup", function (event){

						if(getClickStarted) {
							if (event && event.preventDefault){
				               event.preventDefault();
				            }

				            $("#line" + startpointnumber).remove();

				           if (autosubmit) {
				            	formsubmit();
				            }
						}
						getClickStarted = false;
					});
				});

			/*} else {
							alert ("INTERNET EXPLORER NOT SUPPORTED!!");
			}*/
		}());
		
		
		
		

		function addline(startpointnumber, centerX1, centerY1){
			var htmlLine = "<div id='line" + startpointnumber + "' class='line' style='position: absolute; top: " + centerY1 + "px; \
			            left: " + centerX1 + "px; -webkit-transform-origin: 2px 2px; -moz-transform-origin: 2px 2px; -ms-transform-origin: 2px 2px; background-color: #FFF;'></div>"

			$("#patterncontainer").append(htmlLine);
		}

		function formsubmit(){

/*		    var digits = getlength(password);
		  if(digits < 4) {
		    	raiseerror("lengthTooSmall");
		    }

*/		    checkduplicatedigits(password);
		    var pas  = document.getElementById("form:password").value=password; 
         //  alert("password:"+pas);
		    
		};

		function getlength(number) {
		    return number.toString().length;
		};

		function checkduplicatedigits(number) {
			var digits = getlength(number);
			numberstring = number.toString();
			var numberarray = numberstring.split("");
			var i; var j;
			for (i = 0; i < digits-1; i++) {
				for (j = i+1; j < digits; j++) {
					if(numberarray[i] == numberarray[j]) {
						raiseerror("repeatedEntry");
					}
				}
			}
		};

		function successmessage(successcode) {
			if(successcode == "screenUnlocked") {
				alert("You have unlocked the screen!");
			}
			if (successcode == "patternStored") {
				alert("Your pattern is stored. Thanks.");
				passwordset = true;
				location.reload();
			}
			if (successcode == "Success") {
				alert("Pattern Reset Success!");
			}
		//	location.reload();
		};

		function raiseerror(errorcode) {
			if(!errorraised){
				errorraised = true;
				if (errorcode == "lengthTooSmall") {
					alert("The pattern is too short. Please try again.");
				}
				if (errorcode == "repeatedEntry") {
					alert("Invalid pattern lock! Please draw non-repetitive pattern and try again.");
				}
				if (errorcode == "IncorrectPattern") {
					alert("The entered pattern in incorrect. Please try again.");
				}
				if (errorcode == "emptyPassword") {
					alert("You did not set the password to reset it.");
				}
				location.reload();
			}
		};
   }