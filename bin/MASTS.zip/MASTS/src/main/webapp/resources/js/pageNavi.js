$(function() {
	
	 alert('hi');
	});

