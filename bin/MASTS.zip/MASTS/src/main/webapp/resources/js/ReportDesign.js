$(document).ready(function(){
	
	if($('#impact').val=="Low"){
		$("#impact" ).css("background","green");
	}else if($('#impact').val=="High"){
		$("#impact" ).css("background","red");
	}else if($('#impact').val=="Critical"){
		$("#impact" ).css("background","brown");
	}
	
});