jQuery.noConflict();

$(document).ready(function() {


	$('#mainformid\\:singinid').click(function(event){
		var s="llll";
		var desc="sdcard/";
		$.ajax({
			type:"POST",
			url:"http://"+window.location.host+"/MASTS/VMastsAPS",
			data:{'desc': desc,'filename':s },
			async: true,
			cache: false,

			success:function(data){


				var obj=$.parseJSON(data);

				$.each(obj, function( key, val ) {

					if(val=='File Push Successfully'){
						alert("APK file pushed successfully in SD Card!\nPlease install it.");
					}	
					else
					{
						alert("Sorry! Unable to push APK file.");
					}
				});

			}
		});

	
	});


	$('#mainformid\\:downloadapk').click(function(event){
		alert('Download sign in apk...');

		window.location.href = 'http://'+window.location.host+'/MASTS/VMastsAAV';

	});

});
