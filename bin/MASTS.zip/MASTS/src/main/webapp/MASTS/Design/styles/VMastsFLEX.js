jQuery.noConflict();

var emptyDir="";
var backDir="";
var fileRename="";
var checkStatusfile=0;
var searchCheck="Start";
var valueReturn="fail";
var pattern=/^[a-zA-Z0-9- ._/]+$/;
$(window).bind('setup', function() 
	{
	
	function update() 
	{

		if($('#status').attr('title')=="Connected"){
			if(parseInt(checkStatusfile)==0){
				document.getElementById('unepop').innerHTML = "";
				execute();
			}
		}else{
			checkStatusfile=0;
			valiCloseAll3();
			
		}
		
	
	}

	setInterval(update, 30000);
	update();

	function execute(){

		$('#mytablefile').empty();
		checkStatusfile=parseInt(checkStatusfile)+1;
		$.ajax({
			type:"POST",
			url:"http://"+window.location.host+"/VMastsFEX",
			data:{'dir':'NA','sort':'TYPE'},
			async: true,
			cache: false,

			success:function(data){
				
				var obj=$.parseJSON(data);
				obj1=$.parseJSON(data);
				$('#searchData').val('');

				if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
					if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){
						var thead="<thead>";
						var tbody="<tbody>";
						var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
						$("#mytablefile").append(thead+trhead+tbody); 

						for(var i=0;i < obj.length;i++)
						{
							var objSingle=obj[i].split("\t");

							var objsize = objSingle[4]/1024;
							var finalSize = objsize.toFixed(2);


							if(i%2==0){
								var tr="<tr class='awesome'>";

								if(objSingle[0]=='Dir'){
									var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
								}else if(objSingle[0]=='File'){
									var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
								}

								var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

								var td2="<td><input readonly type='text' value='"+objSingle[2]+"'  style='border:0px;height:auto;padding: 0px;'></input></td>";
								var td3="<td><input readonly type='text' value='"+objSingle[3]+"'  style='border:0px;height:auto;padding: 0px;'></input></td>";
								var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
							}else{
								var tr="<tr class='awesome'>";

								if(objSingle[0]=='Dir'){
									var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
								}else if(objSingle[0]=='File'){
									var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
								}
								var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"'  style='border:0px;height:auto;padding: 0px;'></input></a></td>";

								var td2="<td><input readonly type='text' value='"+objSingle[2]+"'  style='border:0px;height:auto;padding: 0px;'></input></td>";
								var td3="<td><input readonly  type='text' value='"+objSingle[3]+"'  style='border:0px;height:auto;padding: 0px;'></input></td>";
								var td4="<td><input readonly type='text' value='"+finalSize+" KB'  style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
							}
							$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

						}   

					}else{
					
						document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
					}
				}else{
					
					document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
					var dis=$('#currentdir').text();
					var link=dis.split("/");


					var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
					for(var l=1;l<link.length-1;l++){
						newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
					}

					emptyDir=dis;
					$('#currentdir').text('');
					$('#currentdir').html('');
					$('#currentdir').append(newdis);
					
				}

			},
			error:function(data){	

				document.getElementById('unepop').innerHTML = "Error! Unable to retrieve file explorer data. Please try again.";
			}
		});
	}

		});

$(document).ready(function() {
	var obj1;

	$(window).trigger('setup');	

	
	var check="";


	$('#mytablefile').delegate("a", "click", function(){
		vali();
		document.getElementById('unepop').innerHTML = "";
		$('#searchData').val('');
		$('#msg').css({'display':'none'});
		if($(this).children().val()=='File Name'){
			if($('#status').attr("title")=="Connected"){
	
				$("#mytablefile").empty(); 
				var d=$("#currentdir").text();

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':d+"/",'sort':'NAME'},
					async: true,
					cache: false,
					success:function(data){

						var obj=$.parseJSON(data);


						obj.sort();
						if(obj!="" && obj!=undefined && obj.length>=1 && obj ){


							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){
								$("#mytablefile tr").remove(); 
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytablefile").append(trhead); 

								for(var i=0;i< obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									
									var finalSize = objsize.toFixed(2);

									if(i%2==0){
										var tr="<tr>";

										if(objSingle[1]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[1]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[0]+"' title='"+objSingle[1]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}else{
										var tr="<tr>";
										if(objSingle[1]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[1]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[0]+"' title='"+objSingle[1]+"'style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}
									$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

								}  


							}else {

								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}

						}else{
							document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
							var dis=$('#currentdir').text();
							var link=dis.split("/");


							var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
							for(var l=1;l<link.length-1;l++){
								newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
							}

							emptyDir=dis;
							$('#currentdir').text('');
							$('#currentdir').html('');
							$('#currentdir').append(newdis);
						}

					}

				});
			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}

		}else if($(this).children().val()=='Last Modified Date'){
			if($('#status').attr("title")=="Connected"){
				$("#mytablefile").empty(); 
				var d=$("#currentdir").text();
				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':d+"/",'sort':'DATE'},
					async: true,
					cache: false,
					success:function(data){

						var obj=$.parseJSON(data);
						obj.sort();
						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){
								$("#mytablefile tr").remove(); 
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytablefile").append(trhead); 

								for(var i=0;i< obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									//var filesize = objsize/1024;
									var finalSize = objsize.toFixed(2);

									if(i%2==0){
										var tr="<tr>";

										if(objSingle[2]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}else{
										var tr="<tr>";
										if(objSingle[2]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}
									$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

								
								}  

							}else {
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{
							
							document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
							var dis=$('#currentdir').text();
							var link=dis.split("/");


							var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
							for(var l=1;l<link.length-1;l++){
								newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
							}

							emptyDir=dis;
							$('#currentdir').text('');
							$('#currentdir').html('');
							$('#currentdir').append(newdis);
						}

					}
				});

			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}

		}else if($(this).children().val()=='Last Modified Time'){
			if($('#status').attr("title")=="Connected"){
				$("#mytablefile").empty(); 
				var d=$("#currentdir").text();
				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':d+"/",'sort':'TIME'},
					async: true,
					cache: false,
					success:function(data){

						var obj=$.parseJSON(data);

						obj.sort();


						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){


								$("#mytablefile tr").remove(); 
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytablefile").append(trhead); 

								for(var i=0;i< obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var finalSize = objsize.toFixed(2);

									if(i%2==0){
										var tr="<tr>";

										if(objSingle[3]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}else{
										var tr="<tr>";
										if(objSingle[3]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}
									$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

									
								}  
							}else {
							
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{
							
							document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
							var dis=$('#currentdir').text();
							var link=dis.split("/");


							var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
							for(var l=1;l<link.length-1;l++){
								newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
							}

							emptyDir=dis;
							$('#currentdir').text('');
							$('#currentdir').html('');
							$('#currentdir').append(newdis);
						}

					}

				});
			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";

			}
		}else if($(this).children().val()=='Size'){

			if($('#status').attr("title")=="Connected"){
				$("#mytablefile").empty();
				var d=$("#currentdir").text();
				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':d+"/",'sort':'SIZE'},
					async: true,
					cache: false,
					success:function(data){

						var obj=$.parseJSON(data);

						obj.sort();

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){


								$("#mytablefile tr").remove(); 
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytablefile").append(trhead); 

								for(var i=0;i< obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[0]/1024;
									var finalSize = objsize.toFixed(2);

									if(i%2==0){
										var tr="<tr>";

										if(objSingle[4]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[4]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[4]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}else{
										var tr="<tr>";
										if(objSingle[4]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[4]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[4]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}
									$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

								
								}  
							}else {
								
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{
							
							document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
							var dis=$('#currentdir').text();
							var link=dis.split("/");


							var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
							for(var l=1;l<link.length-1;l++){
								newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
							}

							emptyDir=dis;
							$('#currentdir').text('');
							$('#currentdir').html('');
							$('#currentdir').append(newdis);

						}
					}

				});

			}else{

				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else if($(this).children().val()=='Type'){

			if($('#status').attr("title")=="Connected"){
				$("#mytablefile").empty(); 
				var d=$("#currentdir").text();
				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':d+"/",'sort':'TYPE'},
					async: true,
					cache: false,
					success:function(data){

						var obj=$.parseJSON(data);

						obj.sort();
						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){
								$("#mytablefile tr").remove(); 
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytablefile").append(trhead); 

								for(var i=0;i< obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var finalSize = objsize.toFixed(2);

									if(i%2==0){
										var tr="<tr>";

										if(objSingle[0]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}else{
										var tr="<tr>";
										if(objSingle[0]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}
									$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

								}  
							}else {
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{
							
							document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
							var dis=$('#currentdir').text();
							var link=dis.split("/");


							var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
							for(var l=1;l<link.length-1;l++){
								newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
							}

							emptyDir=dis;
							$('#currentdir').text('');
							$('#currentdir').html('');
							$('#currentdir').append(newdis);
						}

					}
				});


			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}

		}else{
			
			if($('#status').attr("title")=="Connected"){
				
				var click;
				
				if($("#ip1").val()=="/"){
					click=$("#ip1").val()+$(this).children().val();
					check=check+"/"+$(this).children().attr("title");
				}else{
					click=$("#ip1").val()+"/"+$(this).children().val();
					check=check+"/"+$(this).children().attr("title");
				}

				if($(this).children().attr("title")=="Dir"){
					var anchor="<a href='#' id='"+$(this).children().val()+"' style='color:black;float:left;'>/"+$(this).children().val()+"</a>";
					$('#currentdir').append(anchor);
					
				}

				$("#prev").val($("#ip1").val());
				$("#ip1").val(click);

				if($(this).children().attr("title")=='File'){
					$("#temp").val($('#currentdir').text()+"/"+$(this).children().val());

				}else{
					$("#temp").val($('#currentdir').text());
				}

				backDir=$('#currentdir').text();
				if($(this).children().attr("title")=='File'){
					fileRename=backDir+"/"+$(this).children().val();
				}else{
					fileRename=backDir;
				}
				
				if($("#src").val()==""){
					$("#selectsrc").css({'display':'block'});
				}

				if($("#srcdir").val()==""){
					$("#selectsrcdir").css({'display':'block'});
				}

				if($("#dfname").val()==""){
					$("#selectfile").css({'display':'block'});
				}
				if($("#ddirname").val()==""){
					$("#selectdir").css({'display':'block'});
				}
				if($("#rfname").val()==""){
					$("#selectrename").css({'display':'block'});
				}

				if($("dname").val()!=""){

					$("#cdirselectdesc").css({'display':'block'});
				}

				$("#temptype").val(check);
				
				var check1=$("#temptype").val();
				var show=$('#currentdir').text();

				if($(this).children().attr("title")=="Dir" || check1.substr((check1.length)-4,check1.length).indexOf("Dir")>=0){

					$.ajax({
						type:"POST",
						url:"http://"+window.location.host+"/VMastsFEX",
						data:{'dir':show+"/",'sort':'TYPE'},
						async: true,
						cache: false,
						success:function(data){

							var obj=$.parseJSON(data);

							if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

								if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

									if(obj[0]!=undefined || obj[1]!=undefined || obj[2]!=undefined || obj[3]!=undefined) {


										$("#mytablefile tr").remove(); 
										var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
										$("#mytablefile").append(trhead); 

										for(var i=0;i< obj.length;i++)
										{
											var objSingle=obj[i].split("\t");

											var objsize = objSingle[4]/1024;
											var finalSize = objsize.toFixed(2);

											if(i%2==0){
												var tr="<tr>";

												if(objSingle[0]=='Dir'){
													var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}else if(objSingle[0]=='File'){
													var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}
												var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

												var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
											}else{
												var tr="<tr>";
												if(objSingle[0]=='Dir'){
													var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}else if(objSingle[0]=='File'){
													var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}
												var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

												var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
											}
											$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 


										}  

									}else{
										document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";

										var dis=$('#currentdir').text();
										var link=dis.split("/");


										var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
										for(var l=1;l<link.length-1;l++){
											newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
										}
										emptyDir=dis;

										$('#currentdir').text('');
										$('#currentdir').html('');
										$('#currentdir').append(newdis);
									}


								}else {
								
									document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
								}
							}else{
								
								document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";

								var dis=$('#currentdir').text();
								var link=dis.split("/");


								var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
								for(var l=1;l<link.length-1;l++){
									newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
								}
								emptyDir=dis;

								$('#currentdir').text('');
								$('#currentdir').html('');
								$('#currentdir').append(newdis);

							}
						}
					});

				}

			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}

		valiCloseAll3();
	});


	$('#currentdir').delegate("a","click",function(event) {
		
		document.getElementById('unepop').innerHTML = "";
		$('#searchData').val('');
		$('#msg').css({'display':'none'});
		var dis=$('#currentdir').text();
		dis=dis.replace(dis.substring(dis.indexOf($(this).text())+$(this).text().length,dis.length),"");

		var link=dis.split("/");
		var newdis="<a href='#' id='"+link[1]+"' style='color:black;float:left;'>/"+link[1]+"</a>";
		for(var l=2;l<link.length;l++){
			newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
		}


		$('#currentdir').text('');
		$('#currentdir').html('');
		$('#currentdir').append(newdis);
		if($('#status').attr("title")=="Connected"){


			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsFEX",
				data:{'dir':dis+"/",'sort':'TYPE'},
				async: true,
				cache: false,
				success:function(data){

					var obj=$.parseJSON(data);

				
					if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

						if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

							$("#mytablefile tr").remove(); 
							var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
							$("#mytablefile").append(trhead); 

							for(var i=0;i< obj.length;i++)
							{	

								var objSingle=obj[i].split("\t");

								var objsize = objSingle[4]/1024;
								var finalSize = objsize.toFixed(2);

								if(i%2==0){
									var tr="<tr>";
									if(objSingle[0]=='Dir'){
										var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									}else if(objSingle[0]=='File'){
										var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									}

									var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

									var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
								}else{
									var tr="<tr>";

									if(objSingle[0]=='Dir'){
										var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									}else if(objSingle[0]=='File'){
										var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									}
									var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

									var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
								}
								$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

							}
						}else {
						
							document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						}
					}else{
						
						document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
						var dis=$('#currentdir').text();
						var link=dis.split("/");


						var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
						for(var l=1;l<link.length-1;l++){
							newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
						}

						emptyDir=dis;
						$('#currentdir').text('');
						$('#currentdir').html('');
						$('#currentdir').append(newdis);

					}

				}
			});


		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});


	//Back button



	$('#back').click(function(event) {
		vali();
	
		document.getElementById('unepop').innerHTML = "";
		$('#searchData').val('');
		$('#msg').css({'display':'none'});
		var dis=$('#currentdir').text();
		
		dis=dis.replace(dis.substring(dis.lastIndexOf("/"),dis.length),"");

		var link=dis.split("/");
		if(link.length > 1){
			backDir="/"+link[1];
			var newdis="<a href='#' id='"+link[1]+"' style='color:black;float:left;'>/"+link[1]+"</a>";
			for(var l=2;l<link.length;l++){
				backDir=backDir+"/"+link[l];
				newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
			}


			$('#currentdir').text('');
			$('#currentdir').html('');
			$('#currentdir').append(newdis);



			if($('#status').attr("title")=="Connected"){


				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':dis+"/",'sort':'TYPE'},
					async: true,
					cache: false,
					success:function(data){

						var obj=$.parseJSON(data);

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){


								$("#mytablefile tr").remove(); 
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytablefile").append(trhead); 

								for(var i=0;i< obj.length;i++)
								{	

									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var finalSize = objsize.toFixed(2);

									if(i%2==0){
										var tr="<tr>";
										if(objSingle[0]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}

										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}else{
										var tr="<tr>";

										if(objSingle[0]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}
									$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

								}
								valiCloseAll3();
							}else {
								
								valiCloseAll3();
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{
							valiCloseAll3();
							document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
							var dis=$('#currentdir').text();
							var link=dis.split("/");


							var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
							for(var l=1;l<link.length-1;l++){
								newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
							}
							emptyDir=dis;

							$('#currentdir').text('');
							$('#currentdir').html('');
							$('#currentdir').append(newdis);
						}


					}

				});


			}else{
				
				valiCloseAll3();
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else{
			$('#currentdir').text('');
			$('#currentdir').html('');
			if($('#status').attr("title")=="Connected"){

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/','sort':'TYPE'},
					async: true,
					cache: false,
					success:function(data){

						var obj=$.parseJSON(data);


						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

								$("#mytablefile tr").remove(); 
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytablefile").append(trhead); 

								for(var i=0;i< obj.length;i++)
								{	

									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var finalSize = objsize.toFixed(2);

									if(i%2==0){
										var tr="<tr>";
										if(objSingle[0]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}

										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}else{
										var tr="<tr>";

										if(objSingle[0]=='Dir'){
											var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										}
										var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

										var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
										var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
									}
									$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

								}   
								valiCloseAll3();
							}else {
							
								valiCloseAll3();
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{
							
							valiCloseAll3();
							document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
							var dis=$('#currentdir').text();
							var link=dis.split("/");


							var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
							for(var l=1;l<link.length-1;l++){
								newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
							}

							emptyDir=dis;
							$('#currentdir').text('');
							$('#currentdir').html('');
							$('#currentdir').append(newdis);
						}


					}

				});
			}else{
				valiCloseAll3();
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}

	});

	$('#mytablefilecopy').delegate("a", "click", function(){
		document.getElementById('unepop').innerHTML = "";
		$(this).children().css({"background-color":"grey","color":"white"});
		var click;

		if($("#ip1").val()=="/"){
			click=$("#ip1").val()+$(this).children().val();
			check=check+"/"+$(this).children().attr("title");
		}else{
			click=$("#ip1").val()+"/"+$(this).children().val();
			check=check+"/"+$(this).children().attr("title");
		}
		if($("#src").val()==""){

			$("#selectsrc").css({'display':'block'});
			$("#prev").val(click);
		}else{
			$("#prev").val(click);
		}

		$("#temptype").val(check);

	});


	//Refresh File Explorer

	$('#refresh').click(function(event){
		vali();
		document.getElementById('unepop').innerHTML = "";
		$('#searchData').val('');
		$('#msg').css({'display':'none'});
		$("#temptype").val("");
		$("#prev").val("");
		$('#downloadf').css({'display':'none'});
		$('#createf').css({'display':'none'});
		$('#created').css({'display':'none'});
		$('#copyf').css({'display':'none'});
		$('#copyd').css({'display':'none'});
		$('#deletef').css({'display':'none'});
		$('#deleted').css({'display':'none'});
		$('#renamefd').css({'display':'none'});
		$('#pushf').css({'display':'none'});
		$("#mytablefilecopy").css({'display':'none'});
		$("#showdownload").css({'display':'block'});
	
		$("#mytablefile").empty();
		var recent=$('#currentdir').text();
		if($('#status').attr("title")=="Connected"){


			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsFEX",
				data:{'dir':recent+"/",'sort':'TYPE'},
				async: true,
				cache: false,
				success:function(data){

					var obj=$.parseJSON(data);

					if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
						if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

							var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
							$("#mytablefile").append(trhead); 

							for(var i=0;i < obj.length;i++)
							{
								var objSingle=obj[i].split("\t");

								var objsize = objSingle[4]/1024;
								var finalSize = objsize.toFixed(2);
								if(i%2==0){
									 var tr="<tr>";

									 if(objSingle[0]=='Dir'){
										 var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }else if(objSingle[0]=='File'){
										 var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }
									 var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

									 var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
								 }else{
									 var tr="<tr>";

									 if(objSingle[0]=='Dir'){
										 var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }else if(objSingle[0]=='File'){
										 var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }
									 var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

									 var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
								 }
								 $("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

							}   

							valiCloseAll3();
						}else {
							valiCloseAll3();
							document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						}
					}else{
						valiCloseAll3();
						document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
						var dis=$('#currentdir').text();
						var link=dis.split("/");


						var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
						for(var l=1;l<link.length-1;l++){
							newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
						}

						emptyDir=dis;
						$('#currentdir').text('');
						$('#currentdir').html('');
						$('#currentdir').append(newdis);
					}
				}
			});

		}else{
			valiCloseAll3();
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
		
	});


	
	$('#home').click(function(event){
		vali();
		document.getElementById('unepop').innerHTML = "";
		$('#currentdir').text('');
		$('#currentdir').html('');
		$('#searchData').val('');
		$('#msg').css({'display':'none'});
		$("#ip1").val("/");
		$("#temp").val("");
		$("#temptype").val("");
		$("#prev").val("");
		$('#downloadf').css({'display':'none'});
		$('#createf').css({'display':'none'});
		$('#created').css({'display':'none'});
		$('#copyf').css({'display':'none'});
		$('#copyd').css({'display':'none'});
		$('#deletef').css({'display':'none'});
		$('#deleted').css({'display':'none'});
		$('#renamefd').css({'display':'none'});
		$('#pushf').css({'display':'none'});
		$("#mytablefilecopy").css({'display':'none'});
		$("#mytablefile").empty();
	
		if($('#status').attr("title")=="Connected"){


			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsFEX",
				data:{'dir':"/",'sort':'TYPE'},
				async: true,
				cache: false,
				success:function(data){

					var obj=$.parseJSON(data);

					if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
						if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

							var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
							$("#mytablefile").append(trhead); 

							for(var i=0;i < obj.length;i++)
							{
								var objSingle=obj[i].split("\t");

								var objsize = objSingle[4]/1024;
								var finalSize = objsize.toFixed(2);
								if(i%2==0){
									 var tr="<tr>";

									 if(objSingle[0]=='Dir'){
										 var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }else if(objSingle[0]=='File'){
										 var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }
									 var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

									 var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
								 }else{
									 var tr="<tr>";

									 if(objSingle[0]=='Dir'){
										 var td0="<td style='width:50px'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }else if(objSingle[0]=='File'){
										 var td0="<td style='width:50px'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									 }
									 var td1="<td><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";

									 var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
									 var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
								 }
								 $("#mytablefile").append(tr+td0+td1+td2+td3+td4); 

							}   

							valiCloseAll3();
						}else {
							valiCloseAll3();
							document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						}
					}else{
						valiCloseAll3();
						document.getElementById('unepop').innerHTML = "Error fetching files! Directory is empty.";
						var dis=$('#currentdir').text();
						var link=dis.split("/");


						var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
						for(var l=1;l<link.length-1;l++){
							newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
						}

						emptyDir=dis;
						$('#currentdir').text('');
						$('#currentdir').html('');
						$('#currentdir').append(newdis);
					}
				}
			});

		}else{
			valiCloseAll3();
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
		
	});




	//Create File...
	$('#create').click(function(event) {

		document.getElementById('unepop').innerHTML = "";
		
		if($('#status').attr("title")=="Connected"){
			$('#searchData').val('');
			$("#createf :text").each(function(){
				$(this).val("");
			});
			$('#createf').css({'display':'block'});
			$('#downloadf').css({'display':'none'});
			$('#created').css({'display':'none'});
			$('#copyf').css({'display':'none'});
			$('#copyd').css({'display':'none'});
			$('#deletef').css({'display':'none'});
			$('#deleted').css({'display':'none'});
			$('#renamefd').css({'display':'none'});
			$('#pushf').css({'display':'none'});
			$('#msg').css({'display':'none'});
		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#cfileselectdesc').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){	
			
			var sourcefile=$("#fname").val();
			if(sourcefile!="")
			{
				if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
					
					$("#cdesc").val(backDir);
					$("#cfileselectdesc").css({'display':'none'});
					$("#createfile").css({'display':'block'});
					$("#canclecreatefile").css({'display':'block'});

				}
				else
				{
					

					document.getElementById('unepop').innerHTML = "Warning! Destination directory not selected. Please select destination directory to proceed.";
				}
			}
			else
			{
				alert("Error! Please input valid file name and try again.");
			}
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";

		}
	});

	$('#canclecreatefile').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){	
			
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				
				$("#cdesc").val("");
				
				var c=$("#ip1").val();
				c=c.substr(0,c.lastIndexOf("/"));
				$("#ip1").val(c);
				$("#cfileselectdesc").css({'display':'block'});
				$("#createfile").css({'display':'none'});
				$("#canclecreatefile").css({'display':'none'});
			
			}else{


				document.getElementById('unepop').innerHTML = "Warning! Destination directory not selected. Please select destination directory to proceed.";
			}
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";

		}
	});
	
	$('#createfile').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		var attr=$("#cdesc").val();

		if(attr.length>1){
			attr=attr+"/"+$('#fname').val();
		}else{
			attr=attr+$('#fname').val();
		}

		var filename=attr;
		$("#cfileselectdesc").css({'display':'block'});
		$("#createfile").css({'display':'none'});
		$("#canclecreatefile").css({'display':'none'});
		
		if(attr!="" && $('#fname').val()!=""){
			if($('#status').attr("title")=="Connected"){
				
				if(filename.indexOf(".")>=0 && pattern.test(filename) == true){

					var fileext = filename.substring((filename.lastIndexOf('.') + 1));
						if(fileext!=""){

						$.ajax({
							type:"POST",
							url:"http://"+window.location.host+"/VMastsOP",
							data:{'attr':attr,'action':'create'},
							async: true,
							cache: false,
							datatype:"json",
							success:function(data){

								var obj=data;
								
								var items = [];
								$.each( obj, function( key, val ) {

									if(val.indexOf("Successfully")>=0){

										document.getElementById('unepop').innerHTML = " File created successfully!";
										$('#created').css({'display':'none'});
										$('#createf').css({'display':'none'});
										$('#tablecopy').css({'display':'none'});
										$("#cfileselectdesc").css({'display':'block'});
										$('#table').css({'display':'block'});
										$('#createfile').css({'display':'none'});
										$("#canclecreatefile").css({'display':'none'});
										$('#fname').val("");
										$("#cdesc").val("");
									}
									else if(val.indexOf("Exist")>=0){
										
										document.getElementById('unepop').innerHTML = "Error! File name already exists. Please try different file name.";
										$("#cfileselectdesc").css({'display':'block'});
										$("#createfile").css({'display':'none'});
										$("#canclecreatefile").css({'display':'none'});
										$('#fname').val("");
										$("#cdesc").val("");
									}else if(val.indexOf("Permission")>=0){

										document.getElementById('unepop').innerHTML = "Error! Access denied. The destination file could not be created.";
										
										$('#fname').val("");
										$("#cdesc").val("");
										$("#cfileselectdesc").css({'display':'block'});
										$("#createfile").css({'display':'none'});
										$("#canclecreatefile").css({'display':'none'});
									}else{
										document.getElementById('unepop').innerHTML = "Error! "+val;
										
									}
								}); 


							},
							error:function(data){

							}

						});

					}else{

						document.getElementById('unepop').innerHTML = "Error! Please input valid file name and try again.";
						$('#fname').focus();
					}


				}else{
					document.getElementById('unepop').innerHTML = "Error! Please input valid file name and try again.";
					$('#fname').focus();
				}

			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else{
			
			document.getElementById('unepop').innerHTML = "Error! Please input valid file name and try again.";
			$('#fname').focus();
		}



	});

	//download

	$('#showdownload').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		$('#div-my-table').empty();
		if($('#status').attr("title")=="Connected"){
			var rc=$('#div-my-table tr').length;
			
			for (var int = 0; int < rc; int++) {

				$("#rr"+int+"").remove();
			}
			$('#searchData').val('');
			$("#downloadf :text").each(function(){
				$(this).val("");
			});
			$('#downloadf').css({'display':'block'});	
			$('#createf').css({'display':'none'});	
			$('#created').css({'display':'none'});
			$('#copyf').css({'display':'none'});
			$('#copyd').css({'display':'none'});
			$('#deletef').css({'display':'none'});
			$('#deleted').css({'display':'none'});
			$('#renamefd').css({'display':'none'});
			$('#pushf').css({'display':'none'});
			$('#msg').css({'display':'none'});
		



			$.ajax({ 
				type: 'POST', 
				url:"http://"+window.location.host+"/VMastsSAD",
				data: { "getda": 'value' }, 
				dataType: 'json',
				success: function (data) { 

					var TableRow;
					var rr=0;
					$("#div-my-table").empty();
					$.each(data, function(index, element) {

						if(element!=null){

							TableRow +="<tr id='rr"+rr+"'><td id='finalc1'><a href='http://"+window.location.host+"/VMastsDSF?na="+element+"' id='aGoogle1'><input readonly type='text' value='"+element+"' title='"+element+"' style='border:0px;height:auto;padding: 0px;'></input></a></td></tr>";

							rr+=1;
						}
					});

					$("#div-my-table").append(TableRow);
				},
				error:function(data){
					$('#downloadf').css({'display':'none'});
					document.getElementById('unepop').innerHTML = "Sorry! File downloads table seems empty. Please download files and try again.";
					
				}
			});

		}
		else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
		$('#div-my-table').delegate("a", "click", function(){
			var v=$(this).children().val();
			document.getElementById('unepop').innerHTML = "";
		});



	});
	
	//Create Directory....

	$('#createdirec').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		$("#cdirselectdesc").css({'display':'block'});
		$("#createdir").css({'display':'none'});
		$("#Backdir").css({'display':'none'});
		if($('#status').attr("title")=="Connected"){
			$('#searchData').val('');
			$("#created :text").each(function(){
				$(this).val("");
			});
			$('#createf').css({'display':'none'});
			$('#created').css({'display':'block'});
			$('#downloadf').css({'display':'none'});
			$('#copyf').css({'display':'none'});
			$('#copyd').css({'display':'none'});
			$('#deletef').css({'display':'none'});
			$('#deleted').css({'display':'none'});
			$('#renamefd').css({'display':'none'});
			$('#pushf').css({'display':'none'});
			$('#msg').css({'display':'none'});
			
		}else{
		
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#cdirselectdesc').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			var scrdirectory=$("#dname").val();
			if(scrdirectory!="")
			{
				if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
					$("#cdirdesc").val(backDir);
					$("#cdirselectdesc").css({'display':'none'});
					$("#createdir").css({'display':'block'});
					$("#Backdir").css({'display':'block'});
				}else{
					
					document.getElementById('unepop').innerHTML = "Warning! Destination directory not selected. Please select destination directory to proceed.";
				}
			}else{
				alert("Please Enter Directory name!");

			}
		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#Backdir').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				$("#cdirdesc").val("");
				
				var c=$("#ip1").val();
				c=c.substr(0,c.lastIndexOf("/"));
				$("#ip1").val(c);
				$("#cdirselectdesc").css({'display':'block'});
				$("#createdir").css({'display':'none'});
				$("#Backdir").css({'display':'none'});
				
			}else{

				document.getElementById('unepop').innerHTML = "Warning! Destination directory not selected. Please select destination directory to proceed.";
			}
		}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});
	
	$('#createdir').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		var attr=$("#cdirdesc").val();
		var scrdirectory=$("#dname").val();
		
		if(attr.length>1){
			attr=attr+"/"+$('#dname').val();
		}else{
			attr=attr+$('#dname').val();
		}
		if(attr!="" && pattern.test(scrdirectory) == true){
			if($('#status').attr("title")=="Connected"){

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'attr':attr,'action':'createdir'},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){
						var obj=data;

						var items = [];
						$.each( obj, function( key, val ) {

							if(val.indexOf("Successfully")>=0){
								
								document.getElementById('unepop').innerHTML = " Directory created successfully!";
								$('#created').css({'display':'none'});
								$('#createf').css({'display':'none'});
								$('#table').css({'display':'block'});
								$("#cdirdesc").val("");
								$('#dname').val("");
								$("#cdirdesc").val("");
								$("#cdirselectdesc").css({'display':'block'});
								$('#createdir').css({'display':'none'});
								$("#Backdir").css({'display':'none'});
							} else if(val.indexOf("Exist")>=0){
								
								document.getElementById('unepop').innerHTML = "Error! File name already exists. Please try different file name.";
								$("#cdirdesc").val("");
								$('#dname').val("");
								$("#cdirselectdesc").css({'display':'block'});
								$("#createdir").css({'display':'none'});
								$("#Backdir").css({'display':'none'});
							}else if(val.indexOf("Permission")>=0){
								document.getElementById('unepop').innerHTML = "Error! Access denied. The destination file could not be created.";
								$("#cdirdesc").val("");
								$('#dname').val("");
								$("#cdirselectdesc").css({'display':'block'});
								$("#createdir").css({'display':'none'});
								$("#Backdir").css({'display':'none'});
							}else{
								
								document.getElementById('unepop').innerHTML = val;
								
							}
						}); 
					}
				});

			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else{
			document.getElementById('unepop').innerHTML = "Warning! Destination directory not selected. Please select destination directory to proceed.";
		}
	});
	//Copy File

	$('#copy').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		$("#selectdesc").css({'display':'none'});
		$("#selectsrc").css({'display':'block'});
		$("#copybtn").css({'display':'none'});
		$('#backcopybtn').css({'display':'none'});
		if($('#status').attr("title")=="Connected"){
			$('#searchData').val('');
			$("#copyf :text").each(function(){
				$(this).val("");
			});
			$('#copyf').css({'display':'block'});
			$('#createf').css({'display':'none'});
			$('#downloadf').css({'display':'none'});
			$('#created').css({'display':'none'});
			$('#copyd').css({'display':'none'});
			$('#deletef').css({'display':'none'});
			$('#deleted').css({'display':'none'});
			$('#renamefd').css({'display':'none'});
			$('#pushf').css({'display':'none'});
			
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#selectsrc').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			var check=$("#temptype").val();
			
			if(check.substr((check.length)-4,check.length).indexOf("File")>=0){
				$("#src").val($("#temp").val());
				$("#ip1").val("");
				$("#prev").val("");

				$("#selectdesc").css({'display':'block'});
				$("#selectsrc").css({'display':'none'});
				$("#temptype").val("");
			}else{
				
			}
		}else{
		
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});

	$('#selectdesc').click(function(event) {
		document.getElementById('unepop').innerHTML = "";

		if($('#status').attr("title")=="Connected"){
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				$("#desc").val(backDir);
				$("#selectdesc").css({'display':'none'});
				$("#copybtn").css({'display':'block'});
				$("#backcopybtn").css({'display':'block'});
			}else{
				
				document.getElementById('unepop').innerHTML = "Warning! Destination directory not selected. Please select destination directory to proceed.";
			}
		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});
	/// changes for the copy the file

	$('#backcopybtn').click(function(event) {
		document.getElementById('unepop').innerHTML = "";

		if($('#status').attr("title")=="Connected"){
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				$("#desc").val("");
				$("#src").val("");
				
				var c=$("#ip1").val();
				c=c.substr(0,c.lastIndexOf("/"));
				$("#ip1").val(c);
				$("#backcopybtn").css({'display':'none'});

				$("#copybtn").css({'display':'none'});
				$("#selectdesc").css({'display':'none'});
				$("#selectsrc").css({'display':'block'});
			
			}else{


				document.getElementById('unepop').innerHTML = "Warning! Destination directory not selected. Please select destination directory to proceed.";
			}
		}else{
		
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});
	///// end the changes

	$('#copybtn').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		var s=$("#src").val();
		var d=$("#desc").val();

		if(s!="" && d!=""){
			if($('#status').attr("title")=="Connected"){	

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'attr':s,'desc':d,'action':'copy'},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){

						var obj=data;

						var items = [];
						$.each( obj, function( key, val ) {

							if(val.indexOf("Successfully")>=0){
								document.getElementById('unepop').innerHTML = "File copied successfully!";

								$('#table').css({'display':'block'});
								$('#copyf').css({'display':'none'});
								$('#tablecopy').css({'display':'none'});
								$("#src").val("");
								$("#desc").val("");
								$("#selectdesc").css({'display':'none'});
								$("#selectsrc").css({'display':'block'});
								$('#copybtn').css({'display':'none'});
								$('#backcopybtn').css({'display':'none'});
							}else if(val.indexOf("Not Exist")>=0){
								
								document.getElementById('unepop').innerHTML = "Sorry! Destination folder does not exists. Please try different destination folder.";

								$("#src").val("");
								$("#desc").val("");
								$("#selectdesc").css({'display':'none'});
								$("#selectsrc").css({'display':'block'});
								$('#backcopybtn').css({'display':'none'});
							}else if(val.indexOf("Permission")>=0){
								document.getElementById('unepop').innerHTML = "Error! Access denied. The destination file could not be copied.";
								$("#src").val("");
								$("#desc").val("");
								$("#selectdesc").css({'display':'none'});
								$("#selectsrc").css({'display':'block'});
								$("#copybtn").css({'display':'none'});
								$('#backcopybtn').css({'display':'none'});
							}else{
						
								$('#table').css({'display':'block'});
								$('#copyf').css({'display':'none'});
								$('#tablecopy').css({'display':'none'});
								$("#src").val("");
								$("#desc").val("");
								$("#selectdesc").css({'display':'none'});
								$("#selectsrc").css({'display':'block'});
								$('#copybtn').css({'display':'none'});
								$('#backcopybtn').css({'display':'none'});
								document.getElementById('unepop').innerHTML = " "+val;

							}	
						}); 



					}});
			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else{
			document.getElementById('unepop').innerHTML = "Error! You have not selected source file and destination location. Please try again.";
		}

	});


	//Copy Directory

	$("#copydir").click(function(event){
		document.getElementById('unepop').innerHTML = "";
		$("#Backcopydirbtn").css({'display':'none'});
		$("#selectdescdir").css({'display':'none'});
		$("#selectsrcdir").css({'display':'block'});
		$('#copydirbtn').css({'display':'none'});
		if($('#status').attr("title")=="Connected"){
			$('#searchData').val('');
			$("#copyd :text").each(function(){
				$(this).val("");
			});
			$('#copyd').css({'display':'block'});
			$('#createf').css({'display':'none'});
			$('#downlaodf').css({'display':'none'});
			$('#created').css({'display':'none'});
			$('#copyf').css({'display':'none'});
			$('#deletef').css({'display':'none'});
			$('#deleted').css({'display':'none'});
			$('#renamefd').css({'display':'none'});
			$('#pushf').css({'display':'none'});
			$('#msg').css({'display':'none'});
			
		}else{
		
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#selectsrcdir').click(function(event) {

		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			var check=$("#temptype").val();
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				$("#srcdir").val($("#temp").val());
				$("#ip1").val("");
				$("#prev").val("");
				$("#selectsrcdir").css({'display':'none'});
				$("#table").css({'display':'block'});
				$("#tablecopy").css({'display':'block'});
				$("#selectdescdir").css({'display':'block'});
				$("#Backcopydirbtn").css({'display':'none'});
				$("#temptype").val("");
			}else{
			
				document.getElementById('unepop').innerHTML = "Error! You have not selected directory. Please try again.";
			}
		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});

	$('#selectdescdir').click(function(event) {
		document.getElementById('unepop').innerHTML = "";

		if($('#status').attr("title")=="Connected"){
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				$("#descdir").val(backDir);
				$("#selectdescdir").css({'display':'none'});
				$("#copydirbtn").css({'display':'block'});
				$("#Backcopydirbtn").css({'display':'block'});
				
			}else{
				
				document.getElementById('unepop').innerHTML = "Error! You have not selected directory. Please try again.";
			}
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});

	/// changes for the back button for copying directory
	$('#Backcopydirbtn').click(function(event) {
		document.getElementById('unepop').innerHTML = "";

		if($('#status').attr("title")=="Connected"){
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				$("#descdir").val($('#currentdir').text());
				$("#selectdescdir").css({'display':'none'});
				$("#copydirbtn").css({'display':'none'});
				$("#Backcopydirbtn").css({'display':'none'});
				$("#selectsrcdir").css({'display':'block'});
				
				$("#srcdir").val("");
				$("#descdir").val("");
				var c=$("#ip1").val();
				c=c.substr(0,c.lastIndexOf("/"));
				$("#ip1").val(c);
				
			}else{


				document.getElementById('unepop').innerHTML = "Please Select Directory From File Explorer!";
			}
		}else{
			document.getElementById('unepop').innerHTML = "Error! You have not selected directory. Please try again.";
		}
	});
	//// end of the chhanges
	$('#copydirbtn').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		var s=$("#srcdir").val();
		var d=$("#descdir").val();

		if(s!="" && d!=""){
			if($('#status').attr("title")=="Connected"){


				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'attr':s,'desc':d,'action':'copy'},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){

						var obj=data;

						var items = [];
						$.each( obj, function( key, val ) {

							if(val.indexOf("Successfully")>=0){
								
								document.getElementById('unepop').innerHTML = " Directory copied successfully!";

								$('#table').css({'display':'block'});
								$('#copyd').css({'display':'none'});
								$('#tablecopy').css({'display':'none'});
								$("#srcdir").val("");
								$("#descdir").val("");
								$("#selectdescdir").css({'display':'none'});
								$("#Backcopydirbtn").css({'display':'none'});
								$("#selectsrcdir").css({'display':'block'});
								$('#copydirbtn').css({'display':'none'});
							}else if(val.indexOf("Not Exist")>=0){
								
								document.getElementById('unepop').innerHTML = "Sorry! Destination folder does not exists. Please try different destination folder.";

								$("#srcdir").val("");
								$("#descdir").val("");
								$("#Backcopydirbtn").css({'display':'none'});
								$("#selectdescdir").css({'display':'none'});
								$("#selectsrcdir").css({'display':'block'});
								$('#copydirbtn').css({'display':'none'});
							}else if(val.indexOf("Permission")>=0){

								document.getElementById('unepop').innerHTML = "Error! Access denied. The destination file could not be created.";
								
								$("#srcdir").val("");
								$("#descdir").val("");
								$("#Backcopydirbtn").css({'display':'none'});
								$("#selectdescdir").css({'display':'none'});
								$("#selectsrcdir").css({'display':'block'});
								$('#copydirbtn').css({'display':'none'});
							}else{
								
								document.getElementById('unepop').innerHTML = val;
							
							}	
						}); 


					}
				});

			
			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else{
				document.getElementById('unepop').innerHTML = "Error! You have not selected source file and destination location. Please try again.";
		}
	});


	//Delete File..

	$('#sdeletef').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		$('#selectfile').css({'display':'block'});
		$('#backdeletefile').css({'display':'block'});
		$('#deletefile').css({'display':'block'});
		if($('#status').attr("title")=="Connected"){
			$('#searchData').val('');
			$("#deletef :text").each(function(){
				$(this).val("");
			});
			$('#deletef').css({'display':'block'});
			$('#deletefile').css({'display':'none'});
			$('#backdeletefile').css({'display':'none'});
			$('#createf').css({'display':'none'});
			$('#downloadf').css({'display':'none'});
			$('#created').css({'display':'none'});
			$('#copyf').css({'display':'none'});
			$('#copyd').css({'display':'none'});
			$('#deleted').css({'display':'none'});
			$('#renamefd').css({'display':'none'});
			$('#pushf').css({'display':'none'});
			$('#table').css({'display':'block'});
			$('#tablecopy').css({'display':'none'});
			$('#msg').css({'display':'none'});
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#selectfile').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			var check=$("#temptype").val();
			
			if(check.substr((check.length)-4,check.length).indexOf("File")>=0){
				$("#dfname").val($("#temp").val());
				$("#ip1").val("");
				$("#prev").val("");
				$("#selectfile").css({'display':'none'});
				$("#backdeletefile").css({'display':'block'});
				$("#deletefile").css({'display':'block'});
				$("#temptype").val("");
			}else{
				
				document.getElementById('unepop').innerHTML = "Error! No file selected. Please select file to delete.";
			}
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});

	// back VMastsOP for delete file
	$('#backdeletefile').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			
			$("#dfname").val("");
			var c=$("#ip1").val();
			c=c.substr(0,c.lastIndexOf("/"));
			$("#ip1").val(c);
			$("#selectfile").css({'display':'block'});
			$("#backdeletefile").css({'display':'none'});
			$("#deletefile").css({'display':'none'});
			
		}
		else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});

	/// end of VMastsOP
	$('#deletefile').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		var s=$("#dfname").val();

		if(s!=""){
			if($('#status').attr("title")=="Connected"){


				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'attr':s,'action':'delete'},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){

						var obj=data;
						var items = [];
						$.each( obj, function( key, val ) {

							if(val.indexOf("Removed Successful")>=0){
								
								document.getElementById('unepop').innerHTML = "File deleted successfully!";
								

								$('#table').css({'display':'block'});
								$('#deletef').css({'display':'none'});
								$('#tablecopy').css({'display':'none'});
								$("#dfname").val("");
								$('#deletefile').css({'display':'none'});
							}else if(val.indexOf("Empty")>=0){

								document.getElementById('unepop').innerHTML = "Selected source file is empty!";

								$("#dfname").val("");
							}else if(val.indexOf("Not Exist")>=0){
								
								document.getElementById('unepop').innerHTML = "Sorry! Destination file or directory does not exists!";
								
								$("#dfname").val("");
							}else{
							
								document.getElementById('unepop').innerHTML = val;
								
							}
						}); 



					}
				});

			}else{
			
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
				
			}
		
		}else{
		
			document.getElementById('unepop').innerHTML = "Error! You have not selected file. Please try again.";
		
		}

	});
	//Delete Directory...

	$('#sdeleted').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		$('#deletedir').css({'display':'none'});
		$('#selectdir').css({'display':'block'});
		$('#backdeletedir').css({'display':'none'});
		if($('#status').attr("title")=="Connected"){
			$('#searchData').val('');
			$("#deleted :text").each(function(){
				$(this).val("");
			});
			$('#msg').css({'display':'none'});
			$('#deleted').css({'display':'block'});
			$('#createf').css({'display':'none'});
			$('#downloadf').css({'display':'none'});
			$('#created').css({'display':'none'});
			$('#copyf').css({'display':'none'});
			$('#copyd').css({'display':'none'});
			$('#deletef').css({'display':'none'});
			$('#renamefd').css({'display':'none'});
			$('#pushf').css({'display':'none'});
			
		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#selectdir').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			var check=$("#temptype").val();
			
			if(check.substr((check.length)-4,check.length).indexOf("Dir")>=0){
				$("#ddirname").val($("#temp").val());
				$("#ip1").val("");
				$("#prev").val("");
				$("#selectdir").css({'display':'none'});

				$("#deletedir").css({'display':'block'});
				$("#backdeletedir").css({'display':'block'});
				$("#temptype").val("");
			}else{
				
				document.getElementById('unepop').innerHTML = "Error! You have not selected file. Please try again.";
			}
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});
	$('#backdeletedir').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			$("#selectdir").css({'display':'block'});
			
			var c=$("#ip1").val();
			c=c.substr(0,c.lastIndexOf("/"));
			$("#ip1").val(c);
			$("#ddirname").val("");
			$("#deletedir").css({'display':'none'});
			$("#backdeletedir").css({'display':'none'});

			document.getElementById('unepop').innerHTML = "Error! You have not selected file. Please try again.";

		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});
	///// end changes
	$('#deletedir').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		var s=$("#ddirname").val();

		if(s!=""){
			if($('#status').attr("title")=="Connected"){

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'attr':s,'action':'delete'},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){

						var obj=data;
						var items = [];
						$.each( obj, function( key, val ) {

							if(val.indexOf("Successfuliy")>=0){
								document.getElementById('unepop').innerHTML = "Directory deleted successfully!";
								$('#table').css({'display':'block'});
								$('#deleted').css({'display':'none'});
								$('#tablecopy').css({'display':'none'});
								$("#ddirname").val("");
								$('#deletedir').css({'display':'none'});
							}else if(val.indexOf("Empty")>=0){
										document.getElementById('unepop').innerHTML = "Selected source file/directory is empty!";
								$("#ddirname").val("");
							}else if(val.indexOf("not Exist")>=0){
							
								document.getElementById('unepop').innerHTML = "Sorry! Source file/directory does not exists.";
								$("#ddirname").val("");
							}else{
								
								document.getElementById('unepop').innerHTML = val;
								
							}	
						}); 



					}
				});

			}else{

				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}

		}else{
			document.getElementById('unepop').innerHTML = "Error! You have not selected file. Please try again.";
		}
	});


	//Rename File/Directory...

	$('#rename').click(function(event){

		document.getElementById('unepop').innerHTML = "";


		if($('#status').attr("title")=="Connected"){

			$("#selectrename").css({'display':'block'});

			$("#renamefile").css({'display':'none'});
			$("#backrenamefile").css({'display':'none'});
			$('#searchData').val('');
			$("#renamefd :text").each(function(){
				$(this).val("");
			});
			$('#msg').css({'display':'none'});
			$('#renamefd').css({'display':'block'});			
			$('#createf').css({'display':'none'});
			$('#downloadf').css({'display':'none'});
			$('#created').css({'display':'none'});
			$('#copyf').css({'display':'none'});
			$('#copyd').css({'display':'none'});
			$('#deletef').css({'display':'none'});
			$('#deleted').css({'display':'none'});	
			$('#pushf').css({'display':'none'});

		}else{

			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	$('#selectrename').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			var sourceval=$("#rnname").val();

			if(sourceval!="")
			{
				

				var check=$("#temptype").val();
				
				$("#rfname").val(fileRename);
				var targetdest=$("#rfname").val();
				if(targetdest!="")
				{

					$("#prev").val("");
					$("#selectrename").css({'display':'none'});

					$("#renamefile").css({'display':'block'});
					$("#backrenamefile").css({'display':'block'});
					
				}
				else
				{
					
				}
				
			}
			else
			{

				document.getElementById('unepop').innerHTML = "Warning! Please specify file name.";
			}
		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});

	//// changes for back button in rename file
	$('#backrenamefile').click(function(event) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			$("#rnname").val("");
			
			$("#rfname").val("");
			var c=$("#ip1").val();
			c=c.substr(0,c.lastIndexOf("/"));
			$("#ip1").val(c);

			$("#selectrename").css({'display':'block'});
			$("#renamefile").css({'display':'none'});
			$("#backrenamefile").css({'display':'none'});
		

		}
		else
		{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
	});
	//// end of the changes

	$('#renamefile').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		var s=$("#rnname").val();
		var n=$("#rfname").val();

		if(s!="" && n!="" && pattern.test(s) == true && pattern.test(n) == true){
			if($('#status').attr("title")=="Connected"){

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'attr':n,'newfile':s,'action':'rename'},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){

						var obj=data;
						var items = [];
						$.each( obj, function( key, val ) {

							if(val.indexOf("Successfull")>=0){
							
								document.getElementById('unepop').innerHTML = "File/Directory renamed successfully!";

								$('#table').css({'display':'block'});
								$('#renamefd').css({'display':'none'});
								$('#tablecopy').css({'display':'none'});
								$("#rfname").val("");
								$("#rnname").val("");
								$("#ip1").val("");
								$('#renamefile').css({'display':'none'});
							
							}else if(val.indexOf("Error")>=0){
								document.getElementById('unepop').innerHTML = "Error! File could not be renamed. Please try again.";

								$("#rfname").val("");
								$("#rnname").val("");
								$("#ip1").val("");
								$("#selectrename").css({'display':'block'});
								$("#renamefile").css({'display':'none'});
								$("#backrenamefile").css({'display':'none'});

							}else if(val.indexOf("Permission")>=0){
								
								document.getElementById('unepop').innerHTML = "Error! Access denied. The file could not be renamed.";

								$("#rfname").val("");
								$("#rnname").val("");
								$("#ip1").val("");
								$("#selectrename").css({'display':'block'});
								$("#renamefile").css({'display':'none'});
								$("#backrenamefile").css({'display':'none'});
							}else if(val.indexOf("not Exist")>=0){
								
								document.getElementById('unepop').innerHTML = "Sorry! Destination file or directory does not exists!";

								$("#rfname").val("");
								$("#rnname").val("");
								$("#ip1").val("");
								$("#selectrename").css({'display':'block'});
								$("#renamefile").css({'display':'none'});
								$("#backrenamefile").css({'display':'none'});
							}else{
								
								document.getElementById('unepop').innerHTML = val;
								
							}
						});



					}
				});
			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else{

			document.getElementById('unepop').innerHTML = "Warning! Please specify file name.";
		}


	});


	//Download File...

	$('#download').click(function(event){
		vali();
		document.getElementById('unepop').innerHTML = "";
		
		$('#msg').css({'display':'none'});
		$('#pushf').css({'display':'none'});
		$('#createf').css({'display':'none'});
		$('#downloadf').css({'display':'none'});
		$('#created').css({'display':'none'});
		$('#copyf').css({'display':'none'});
		$('#copyd').css({'display':'none'});
		$('#deletef').css({'display':'none'});
		$('#deleted').css({'display':'none'});
		$('#renamefd').css({'display':'none'});

		var s=$("#temp").val();
		var check=$("#temptype").val();
		
		var arrayOfStrings = check.split("/");
		var length=(arrayOfStrings.length)-1;
		
		if($('#status').attr("title")=="Connected"){
			if(arrayOfStrings[length].indexOf("File")>=0){

				if (confirm("Do you want to download "+s+" ?")) {
					var arrayOfvalue=s.split("/");
					var l=(arrayOfvalue.length)-1;
					var filename=arrayOfvalue[l];


					$.ajax({
						type:"POST",
						url:"http://"+window.location.host+"/VMastsOP",
						data:{'attr':s,'filename':filename,'action':'downloadfile'},
						async: true,
						cache: false,
						
						success:function(data){

							var obj=$.parseJSON(data);

							var items = [];
							$.each(obj, function( key, val ) {

								if(key=='msg'){
									document.getElementById('unepop').innerHTML = val;
									
									valiCloseAll3();
									$('#downloadf').css({'display':'block'})
									$.ajax({ 
										type: 'POST', 
										url:"http://"+window.location.host+"/VMastsSAD",
										data: { "getda": 'value' }, 
										dataType: 'JSON',
										success: function (data) { 
											var TableRow;
											$("#div-my-table").empty();
											$.each(data, function(index, element) {
												if(element!=null && element.indexOf(filename)>=0){
													$("#output").append( " "+element);
													$("#output").append("</br>")
													TableRow +="<tr id='rr'><td id='finalc1'><a href='http://"+window.location.host+"/VMastsDSF?na="+element+"' id='aGoogle1'><input readonly type='text' value='"+element+"' title='"+element+"' style='border:0px;height:auto;padding:0px;background-color:#bbbbbb;color:white;'></input></a></td></tr>";
												}else{
													$("#output").append( " "+element);
													$("#output").append("</br>")
													TableRow +="<tr id='rr'><td id='finalc1'><a href='http://"+window.location.host+"/VMastsDSF?na="+element+"' id='aGoogle1'><input readonly type='text' value='"+element+"' title='"+element+"' style='border:0px;height:auto;padding: 0px;'></input></a></td></tr>";
												}
											});

											$("#div-my-table").append(TableRow);
										},
										error:function(data){
											$('#downloadf').css({'display':'none'});
											document.getElementById('unepop').innerHTML = "Sorry! File downloads table seems empty. Please download files and try again.";
											
										}
									});
								}
								
							}); 



						}
					});
				}else{
					valiCloseAll3();
				}
			}else{
				alert("You have not selected any file. Please try again.");
				valiCloseAll3();
				document.getElementById('unepop').innerHTML = "Error! You have not selected file. Please try again.";
			}


		}else{
			valiCloseAll3();
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}



	});


	//Download Dir....


	$('#downloaddir').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		vali();
		
		$('#pushf').css({'display':'none'});
		$('#createf').css({'display':'none'});
		$('#downloadf').css({'display':'none'});
		$('#created').css({'display':'none'});
		$('#copyf').css({'display':'none'});
		$('#copyd').css({'display':'none'});
		$('#deletef').css({'display':'none'});
		$('#deleted').css({'display':'none'});
		$('#renamefd').css({'display':'none'});

		var s=backDir;
		var check=$("#temptype").val();
		var arrayOfStrings = check.split("/");
		var length=(arrayOfStrings.length)-1;
	
		if($('#status').attr("title")=="Connected"){

			if(arrayOfStrings[length].indexOf("Dir")>=0){
				if(confirm("Do you want to download "+s+" ?")){


					var arrayOfvalue=s.split("/");
					var l=(arrayOfvalue.length)-1;
					var filename=arrayOfvalue[l];

					$.ajax({
						type:"POST",
						url:"http://"+window.location.host+"/VMastsOP",
						data:{'attr':s,'action':'downloaddir'},
						async: true,
						cache: false,

						success:function(data){

							
							var items = [];
							$.each( data, function( key, val ) {
								if(key=='msg'){
									valiCloseAll3();
									document.getElementById('unepop').innerHTML = val;

									$('#downloadf').css({'display':'block'})
									$.ajax({ 
										type: 'POST', 
										url:"http://"+window.location.host+"/VMastsSAD",
										data: { "getda": 'value' }, 
										dataType: 'JSON',
										success: function (data) { 
											var TableRow;
											$("#div-my-table").empty();
											$.each(data, function(index, element) {
												var dd=s.substring(s.lastIndexOf("/"),s.length)+".zip";
												
												var check="/"+element;
												
												if(element!=null && dd==check){
													$("#output").append( " "+element);
													$("#output").append("</br>")
													TableRow +="<tr id='rr'><td id='finalc1'><a href='http://"+window.location.host+"/VMastsDSF?na="+element+"' id='aGoogle1'><input readonly type='text' value='"+element+"' title='"+element+"' style='border:0px;height:auto;padding:0px;background-color:#bbbbbb;color:white;'></input></a></td></tr>";
												}else{
													$("#output").append( " "+element);
													$("#output").append("</br>")
													TableRow +="<tr id='rr'><td id='finalc1'><a href='http://"+window.location.host+"/VMastsDSF?na="+element+"' id='aGoogle1'><input readonly type='text' value='"+element+"' title='"+element+"' style='border:0px;height:auto;padding: 0px;'></input></a></td></tr>";
												}
											});

											$("#div-my-table").append(TableRow);
										},
										error:function(data){
											$('#downloadf').css({'display':'none'});
											document.getElementById('unepop').innerHTML = "Sorry! File downloads table seems empty. Please download files and try again.";
											
										}
									});
								}

							}); 
						}
					});
				}else{
					valiCloseAll3();
				}

			}else{
				alert("You have not selected any directory. Please try again.");


				document.getElementById('unepop').innerHTML = "Error! You have not selected any directory. Please try again.";
				valiCloseAll3();
			}
		}else{

			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			valiCloseAll3();
		}
	});

	$("#searchData").keypress(function(e) {
		 if(e.which == 13) {
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr("title")=="Connected"){
			if(searchCheck=="Start"){
				
				var search=$('#searchData').val();
				var recent=backDir;
				if(recent==""){
					recent="/";
				}
				var pattern=/^[a-zA-Z0-9- ._]+$/;
				if(search!="" && search!=null && pattern.test(search) == true){
					searchCheck="in process";
					vali();
					$('#mytablefile').empty();
					$('#mytablefile').css({'display':'block'});
					$('#table').css({'display':'none'});
					
					document.getElementById('unepop').innerHTML = "Searching Started!";
					var searchStatus="";
					if(recent=="/"){
						
						$.ajax({
							type:"POST",
							url:"http://"+window.location.host+"/VMastsFEX",
							data:{'dir':"/",'sort':'TYPE'},
							async: true,
							cache: false,
							datatype:"json",
							success:function(data){

								var obj=$.parseJSON(data);
								if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

									if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

										var thead="<thead>";
										var tbody="<tbody>";
										var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
										$("#mytablefile").append(thead+trhead+tbody); 
										obj.sort();
										for(var i=0;i < obj.length;i++)
										{
											var objSingle=obj[i].split("\t");

											var objsize = objSingle[4]/1024;
											var finalSize = objsize.toFixed(2);

											if(objSingle[1].toLowerCase().indexOf(search.toLowerCase())>=0){

												if(i%2==0){
													var tr="<tr class='awesome'>";

													if(objSingle[0]=='Dir'){
														var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
													}else if(objSingle[0]=='File'){
														var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
													}

													var td1="<td><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";

													var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
													var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
													var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
												}else{
													var tr="<tr class='awesome'>";

													if(objSingle[0]=='Dir'){
														var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
													}else if(objSingle[0]=='File'){
														var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
													}
													var td1="<td><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";

													var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
													var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
													var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
												}
												$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 
												searchStatus="success";
												break;
											}else{
												
											}
										}

										if(searchStatus!="success"){
											 setTimeout(function() {
												 $.fn.searchdir(obj,recent);
											 }, 10000);
											
										}


										
											  setTimeout(function() {
												  if(searchStatus=="success"){
														
														document.getElementById('unepop').innerHTML = "Search completed! File/Directory found.";
													}else if(valueReturn=="success"){
														document.getElementById('unepop').innerHTML = "Search completed! File/Directory found.";
													}else{
														
														$("#mytablefile").empty();
														document.getElementById('unepop').innerHTML = "Search completed! File/Directory not found.";
													}
													searchCheck="Start";
													valiCloseAll3();
											  }, 15000);
										
										

									}else {

										document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
									}
								}else{
									var dis=$('#currentdir').text();
									var link=dis.split("/");


									var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
									for(var l=1;l<link.length-1;l++){
										newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
									}

									emptyDir=dis;
									$('#currentdir').text('');
									$('#currentdir').html('');
									$('#currentdir').append(newdis);

								}
							}
						});

					}else{
						

						$.ajax({
							type:"POST",
							url:"http://"+window.location.host+"/VMastsFEX",
							data:{'dir':recent+"/",'sort':'TYPE'},
							async: true,
							cache: false,
							success:function(data){

								var obj=$.parseJSON(data);

								if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

									if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

										var thead="<thead>";
										var tbody="<tbody>";
										var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
										$("#mytablefile").append(thead+trhead+tbody); 

										obj.sort();
										for(var i=0;i < obj.length;i++)
										{
											var objSingle=obj[i].split("\t");

											var objsize = objSingle[4]/1024;
											var finalSize = objsize.toFixed(2);
											if(objSingle[1].toLowerCase().indexOf(search.toLowerCase())>=0){


												var tr="<tr class='awesome'>";

												if(objSingle[0]=='Dir'){
													var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}else if(objSingle[0]=='File'){
													var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}

												var td1="<td><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";

												var td2="<td><input readonly type='text' value='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td3="<td><input readonly type='text' value='"+objSingle[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";

												$("#mytablefile").append(tr+td0+td1+td2+td3+td4);
												searchStatus="success";
												break;
											}else{
											}
										}
										if(searchStatus!="success"){
											 setTimeout(function() {
												 $.fn.searchdir(obj,recent);
											 }, 10000);
											
										}
										
										  setTimeout(function() {
											  if(searchStatus=="success"){
													
													document.getElementById('unepop').innerHTML = "Search completed! File/Directory found.";
												}else if(valueReturn=="success"){
													document.getElementById('unepop').innerHTML = "Search completed! File/Directory found.";
												}else{
													
													$("#mytablefile").empty();
													document.getElementById('unepop').innerHTML = "Search completed! File/Directory not found.";
												}
												searchCheck="Start";
												valiCloseAll3();
										  }, 15000);
									
									}else {
										////alert("Session Expired! \n Login Required On Device! \n Or Refresh the Page");
										document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
									}
								}else{
									////alert("Please Send Valid Data");

									//document.getElementById('unepop').innerHTML = "Selected directory is empty!";
									var dis=$('#currentdir').text();
									var link=dis.split("/");


									var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
									for(var l=1;l<link.length-1;l++){
										newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
									}

									emptyDir=dis;
									$('#currentdir').text('');
									$('#currentdir').html('');
									$('#currentdir').append(newdis);
								}
							}
						});

						//$.getJSON("http://"+window.location.host+"/VMastsFEX?dir="+recent+"/&sort=TYPE", function(data) {});
					}

				}else{
				
					document.getElementById('unepop').innerHTML = "Warning! Please specify file name.";
					$('#msg').text("");
					//$("#mytablefile").empty();
					//alert("Please Enter Data!!");

				}
				$('#table').css({'display':'block'});
			}
		}else{
			////alert("Make Sure!"+"\n"+"Device is Connected or Not!");

			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
		 }
	});


	$.fn.searchdir = function(obj,recent) { 
		
		if($('#status').attr("title")=="Connected"){
			var search=$('#searchData').val();
			//alert(recent);
			var objinternal;
			var newRecent;
		
			if(recent=="/"){
				for(var i=0;i < obj.length;i++)
				{
					var objSingle=obj[i].split("\t");
					if(objSingle[0]=='Dir'){
						newRecent=recent+"/"+objSingle[1]+"/";
					
						$.ajax({
							type:"POST",
							url:"http://"+window.location.host+"/VMastsFEX",
							data:{'dir':recent+objSingle[1]+"/",'sort':'TYPE'},
							async: true,
							cache: false,
							success:function(data){

								var obj=$.parseJSON(data);
								var titlemsg="";
								if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

									if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

										objinternal=obj;
										objinternal.sort();
										for(var i=0;i < objinternal.length;i++)
										{
											
											var objSingleIn=objinternal[i].split("\t");

											var objsize = objSingleIn[4]/1024;
											var finalSize = objsize.toFixed(2);
											
											if(objSingleIn[1].toLowerCase().indexOf(search.toLowerCase())>=0){

												titlemsg=recent+objSingle[1]+"/";
												var tr="<tr class='awesome'>";

												if(objSingleIn[0]=='Dir'){
													var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}else if(objSingleIn[0]=='File'){
													var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}

												var td1="<td><input readonly type='text' value='"+objSingleIn[1]+"' title='"+objSingleIn[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";

												var td2="<td><input readonly type='text' value='"+objSingleIn[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td3="<td><input readonly type='text' value='"+objSingleIn[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";

												$("#mytablefile").append(tr+td0+td1+td2+td3+td4); 
												valueReturn="success";
												//$('#currentdir').text(recent+objSingle[1]+"/"+objSingleIn[1]);
												break;
											}else{
												
											}

										}
										
										if(valueReturn!="success"){
											 setTimeout(function() {
												 $.fn.searchdir(obj,recent+objSingle[1]);
											 }, 10000);
											
										}

									}else {

										document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
									}
								}else{

									var dis=$('#currentdir').text();
									var link=dis.split("/");


									var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
									for(var l=1;l<link.length-1;l++){
										newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
									}

									emptyDir=dis;
									$('#currentdir').text('');
									$('#currentdir').html('');
									$('#currentdir').append(newdis);
								}
							}
						});
					}

				} 
			}else{
				for(var i=0;i < obj.length;i++)
				{
					var objSingle=obj[i].split("\t");
					if(objSingle[0]=='Dir'){
						newRecent=recent+"/"+objSingle[1]+"/";
						
						$.ajax({
							type:"POST",
							url:"http://"+window.location.host+"/VMastsFEX",
							data:{'dir':recent+"/"+objSingle[1]+"/",'sort':'TYPE'},
							async: true,
							cache: false,
							success:function(data){

								var obj=$.parseJSON(data);
								var titlemsg;
								if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

									if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

										objinternal=obj;
										objinternal.sort();
										for(var i=0;i < objinternal.length;i++)
										{
											
											var objSingleInt=objinternal[i].split("\t");

											var objsize = objSingleInt[4]/1024;
											var finalSize = objsize.toFixed(2);

											
											if(objSingleInt[1].toLowerCase().indexOf(search.toLowerCase())>=0){
												titlemsg=recent+objSingle[1]+"/";

												var tr="<tr class='awesome'>";

												if(objSingleInt[0]=='Dir'){
													var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}else if(objSingleInt[0]=='File'){
													var td0="<td style='width:50px;background-color:#bbbbbb;'><img src='images/file-1.png' width='15' height='15' style='margin-left: 30%;'/></td>";
												}

												var td1="<td><input readonly type='text' value='"+objSingleInt[1]+"' title='"+objSingleInt[0]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";

												var td2="<td><input readonly type='text' value='"+objSingleInt[2]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td3="<td><input readonly type='text' value='"+objSingleInt[3]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
												var td4="<td><input readonly type='text' value='"+finalSize+" KB' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";

												$("#mytablefile").append(tr+td0+td1+td2+td3+td4);
												valueReturn="success";
												$('#currentdir').text(recent+objSingle[1]+"/"+objSingleIn[1]);
												break;
											}else{
												
											}

										}
										
										if(valueReturn!="success"){
											 setTimeout(function() {
												 $.fn.searchdir(obj,recent+objSingle[1]);
											 }, 10000);
											
										}
										
									}else {
										
										document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
									}
								}else{
									var dis=$('#currentdir').text();
									var link=dis.split("/");


									var newdis="<a href='#' id='"+link[0]+"' style='color:black;float:left;'>"+link[0]+"</a>";
									for(var l=1;l<link.length-1;l++){
										newdis=newdis+"<a href='#' id='"+link[l]+"' style='color:black;float:left;'>/"+link[l]+"</a>";
									}
									emptyDir=dis;

									$('#currentdir').text('');
									$('#currentdir').html('');
									$('#currentdir').append(newdis);
								}
							}
						});

						
					}

				} 
			}	
		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}		

	}

});



function vali()
{
	$('#overlay').fadeIn('fast',function(){
		$('#box').show();
		$('#box').animate({'top':'35%'},500);
	});
}
function valiCloseAll3(){
	var $j5 = jQuery.noConflict();
	$j5('#overlay').fadeOut('fast',function(){
		$j5('#box').hide();
	});
}
