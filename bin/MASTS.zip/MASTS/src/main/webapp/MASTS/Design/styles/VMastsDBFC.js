jQuery.noConflict();
var apkpath = '';
var checkStatusdbchooser=0;
$(window).bind('setup', function() {
	function update() {
		
		if($('#status').attr('title')=="Connected"){
			if(parseInt(checkStatusdbchooser)==0){
				document.getElementById('unepop').innerHTML = "";
				execute();
			}
		}else{
			checkStatusdbchooser=0;
			
			valiCloseAll2();
			
		}
		
	
	}


	setInterval(update, 30000);
	update();

	function execute(){	
		checkStatusdbchooser=parseInt(checkStatusdbchooser)+1;
		$("#mytabledbapp").empty(); 
		$.ajax({
			type:"POST",
			url:"http://"+window.location.host+"/VMastsFEX",
			data:{'dir':'/data/app/','sort':'DATE'},
			async: true,
			cache: false,

			success:function(data){

				var obj=$.parseJSON(data);

				obj1=obj;

				if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
					if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
						var thead="<thead>";
						var tbody="<tbody>";
						var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
						$("#mytabledbapp").append(thead+trhead+tbody); 



						for(var i=0;i < obj.length;i++)
						{
							var objSingle=obj[i].split("\t");

							var objsize = objSingle[4]/1024;
							var filesize = objsize/1024;
							var finalSize = filesize.toFixed(2);

							if(i%2==0){
								var tr="<tr class='awesome'>";								
								if(objSingle[2]=='Dir'){
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
								}else if(objSingle[2]=='File'){
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
									var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
								}
								var td2="<td class='even' style='width:20%'>"+objSingle[0]+"</td>";
								var td3="<td class='even' style='width:20%'>"+objSingle[3]+"</td>";
								var td4="<td class='even' style='width:20%'>"+finalSize+" MB</td></tr>";

							}else{
								var tr="<tr class='awesome'>";

								/*if(objSingle[2]=='Dir'){
									var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
								}else if(objSingle[2]=='File'){
									var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
								}
								var td1="<td class='odd'>"+objSingle[1]+"</td>";
*/
								if(objSingle[2]=='Dir'){
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
								}else if(objSingle[2]=='File'){
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
									var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
								}
								var td2="<td class='odd'>"+objSingle[0]+"</td>";
								var td3="<td class='odd'>"+objSingle[3]+"</td>";
								var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
							}
							$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

						}							
					}else{

						document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
					}
				}else{

					document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
				}

			}
		});

	}

});



$(document).ready(function() {
	var obj1;
	$(window).trigger('setup');



	$('#mytabledbapp').delegate("a", "click", function(){
		document.getElementById('unepop').innerHTML = "";
		if($(this).children().val()=='File Name'){
			if($('#status').attr("title")=="Connected"){
				$("#mytabledbapp").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'NAME'},
					async: true,
					cache: false,

					success:function(data){

						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Type</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytabledbapp").append(thead+trhead+tbody); 

								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";


										
										if(objSingle[1]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[0]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[1]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[0]+"</td>";
										}
										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										
										if(objSingle[1]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[0]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[1]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[0]+"</td>";
										}

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{

								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}

						}else{

							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						}

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else if($(this).children().val()=='Last Modified Date'){

			if($('#status').attr("title")=="Connected"){
				$("#mytabledbapp").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'DATE'},
					async: true,
					cache: false,

					success:function(data){
						
						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytabledbapp").append(thead+trhead+tbody); 



								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										/*if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
										}

										var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";*/

										
										if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}
										var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										/*if(objSingle[2]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
										}
										var td1="<td class='odd'>"+objSingle[1]+"</td>";*/
										
										if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										var td2="<td class='odd'>"+objSingle[0]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{

								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{

							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						}

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}



		}else if($(this).children().val()=='Last Modified Time'){

			if($('#status').attr("title")=="Connected"){
				$("#mytabledbapp").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'TIME'},
					async: true,
					cache: false,

					success:function(data){
						var obj=$.parseJSON(data);

						obj1=obj;
						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytabledbapp").append(thead+trhead+tbody); 

								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										/*if(objSingle[3]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td></td>";
										}

										var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";*/
										
										if(objSingle[3]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										/*if(objSingle[3]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
										}
										var td1="<td class='odd' >"+objSingle[1]+"</td>";*/
										
										if(objSingle[3]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[0]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{

								 document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
							 }

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else if($(this).children().val()=='Size'){


			if($('#status').attr("title")=="Connected"){
				$("#mytabledbapp").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'SIZE'},
					async: true,
					cache: false,

					success:function(data){
				
						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytabledbapp").append(thead+trhead+tbody); 

								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[0]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";


										if(objSingle[4]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[4]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";


										if(objSingle[4]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[4]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{
							
								document.getElementById('unepop').innerHTML = "Session Expired! Login Required On Device! \n Or Refresh the Page";
							}

						}else{

							document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						}

					}
				});
			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else if($(this).children().val()=='Select'){
			if($('#status').attr("title")=="Connected"){
				$("#mytabledbapp").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'TYPE'},
					async: true,
					cache: false,

					success:function(data){
						var obj=$.parseJSON(data);

						obj1=obj;
						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytabledbapp").append(thead+trhead+tbody); 
								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[0]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";
										if(objSingle[0]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{

								 document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
							 }

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}


		}else{

			var dir = $(this).children().val();
			//alert("Selected Dir :"+dir);
			apkpath = dir;
			if($('#status').attr("title")=="Connected"){
				$("#mytabledbapp").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/'+dir+'/','sort':'DATE'},
					async: true,
					cache: false,

					success:function(data){
						//alert(data);

						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
								$("#mytabledbapp").append(thead+trhead+tbody); 



								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");
									
									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										if(objSingle[2]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='odd'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='odd'>"+objSingle[1]+"</td>";
										}
										

										var td2="<td class='odd'>"+objSingle[0]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{

								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{

							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						}

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
			
			
			
		
		}


	});
	$('#mytabledbapp').delegate("button", "click", function(){
		document.getElementById('unepop').innerHTML = "";
		var sub1=$(this).val();

		if(sub1.indexOf('.apk') != -1){
			var filename=$(this).val();
			if($('#status').attr("title")=="Connected"){	

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'dir':'/data/app/'+apkpath+'/'+filename,'filename':filename,'action':'databasegetappname'},
					async: true,
					cache: false,
					
					success:function(data){
						
						document.getElementById('unepop').innerHTML = "APK file selected and database retrieved successfully! Click Next.";
						valiCloseAll2();
					},
					error:function(data){

						
						document.getElementById('unepop').innerHTML = "Error! APK database download failed. Please try again.";
						valiCloseAll2();
					}
				});

				
			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
				valiCloseAll2();

			}


		}
		else{
			valiCloseAll2();
			PF('msg').renderMessage({"summary":"Warning!",
				"detail":"No APK file selected. Please select APK file and try again.",
				"severity":"info"});
			document.getElementById('unepop').innerHTML = "Warning! No APK file selected. Please select APK file and try again.";
		}






	});


	$('#refresh').click(function(event){
		document.getElementById('unepop').innerHTML = "";
		vali();

		if($('#status').attr('title')==('Connected')){
			$("#showdbname").text("");
			//$("#table").show();
			$("#mytabledbapp").show();
			$('#mytabledbapp').empty();


			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsFEX",
				data:{'dir':'/data/app/','sort':'DATE'},
				async: true,
				cache: false,

				success:function(data){
					
					var obj=$.parseJSON(data);

					obj1=obj;

					if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
						
						if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
							
							var thead="<thead>";
							var tbody="<tbody>";
							var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
							$("#mytabledbapp").append(thead+trhead+tbody); 

							for(var i=0;i < obj.length;i++)
							{
								var objSingle=obj[i].split("\t");

								var objsize = objSingle[4]/1024;
								var filesize = objsize/1024;
								var finalSize = filesize.toFixed(2);

								if(i%2==0){
									var tr="<tr class='awesome'>";

									/*if(objSingle[2]=='Dir'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
									}else if(objSingle[2]=='File'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
									}

									var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";*/
									
									if(objSingle[2]=='Dir'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
									}else if(objSingle[2]=='File'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
										var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
									}

									var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
									var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
									var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
								}else{
									var tr="<tr class='awesome'>";

									/*if(objSingle[2]=='Dir'){
										var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
									}else if(objSingle[2]=='File'){
										var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='select_button'></button></td>";
									}
									var td1="<td class='odd'>"+objSingle[1]+"</td>";*/
									if(objSingle[2]=='Dir'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
									}else if(objSingle[2]=='File'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
										var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
									}

									var td2="<td class='odd'>"+objSingle[0]+"</td>";
									var td3="<td class='odd'>"+objSingle[3]+"</td>";
									var td4="<td class='odd'>"+finalSize+"</td></tr>";
								}
								$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 

							}							
						}else{
							
							document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						}

									}else{

							 document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						 }

				}
			});

		}else{
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";

		}
		valiCloseAll2();
	});
	var check="";


	$("#searchData").keypress(function(e) {
		 if(e.which == 13) {
		document.getElementById('unepop').innerHTML = "";
		vali();
		if($('#status').attr("title")=="Connected"){
			var search=$('#searchData').val();

			var searchStatus;

			var pattern=/^[a-zA-Z0-9- ._/]+$/;
			if(search!="" && search!=null && pattern.test(search) == true){
				$('#mytabledbapp').empty();
					$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'DATE'},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){

						var obj=$.parseJSON(data);
						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:40%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Size</label></th>";
								$("#mytabledbapp").append(thead+trhead+tbody); 
								obj.sort();
								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");

									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(objSingle[1].toLowerCase().indexOf(search.toLowerCase())>=0){


										var tr="<tr class='awesome'>";

										/*if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
										}

										var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";*/
										if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";

										$("#mytabledbapp").append(tr+td0+td1+td2+td3+td4); 
										searchStatus="success";
									}else{
									
									}
								}

								valiCloseAll2();
								if(searchStatus=="success"){

									document.getElementById('unepop').innerHTML = "Search completed! APK file(s) found.";
								}else{
									$("#mytabledbapp").empty();
									document.getElementById('unepop').innerHTML = "Search completed! APK file(s) Not found.";
								}
							}else {
								
								valiCloseAll2();
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{
							
							valiCloseAll2();
							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";

						}
					}
				});

			}else{
				valiCloseAll2();
				document.getElementById('unepop').innerHTML = " Sorry! Could not perform search operation. Please input valid data and try again.";

			}
		}else{
			valiCloseAll2();
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}
		 }
	});

});
function vali()
{
	$('#overlay').fadeIn('fast',function(){
		$('#box').show();
		$('#box').animate({'top':'35%'},500);
	});
}
function valiCloseAll2(){
	var $j5 = jQuery.noConflict();
	$j5('#overlay').fadeOut('fast',function(){
		$j5('#box').hide();
	});
}
