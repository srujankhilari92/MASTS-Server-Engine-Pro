jQuery.noConflict();
var checkStatus=0;
var searchCheck="Start";
var apkpath = '';
$(window).bind('setup', function() {
	function update() {

		if($('#status').attr('title')=="Connected"){
			if(parseInt(checkStatus)==0){
				document.getElementById('unepop').innerHTML = "";
				execute();
			}
		}else{
			checkStatus=0;
			valiCloseAll1();
			
		}
	}


	setInterval(update, 30000);
	update();

	function execute(){	
		checkStatus=parseInt(checkStatus)+1;
		$("#mytable").empty(); 
		$.ajax({
			type:"POST",
			url:"http://"+window.location.host+"/VMastsFEX",
			data:{'dir':'/data/app/','sort':'DATE'},
			async: true,
			cache: false,

			success:function(data){
                
				var obj=$.parseJSON(data);
			
				obj1=obj;
                 
				if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
					if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
						var thead="<thead>";
						var tbody="<tbody>";
						var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='width:7%; text-align:center;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
						$("#mytable").append(thead+trhead+tbody); 


						for(var i=0;i < obj.length;i++)
						{
							var objSingle=obj[i].split("\t");
							
							var objsize = objSingle[4]/1024;
							var filesize = objsize/1024;
							var finalSize = filesize.toFixed(2); 
							if(i%2==0){
								var tr="<tr class='awesome'>";

								if(objSingle[2]=='Dir'){
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center;'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
									var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
								}else if(objSingle[2]=='File'){
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
									var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
								}

								

								var td2="<td class='even' style='width:20%'>"+objSingle[0]+"</td>";
								var td3="<td class='even' style='width:20%'>"+objSingle[3]+"</td>";
								var td4="<td class='even' style='width:20%'>"+finalSize+" MB</td></tr>";

							}else{
								var tr="<tr class='awesome'>";

								if(objSingle[2]=='Dir'){
									var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></button></td>";
									var td1="<td class='odd' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
								}else if(objSingle[2]=='File'){
									var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
									var td1="<td class='odd' style='width:40%;'>"+objSingle[1]+"</td>";
								}
								

								var td2="<td class='odd'>"+objSingle[0]+"</td>";
								var td3="<td class='odd'>"+objSingle[3]+"</td>";
								var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
							}
							$("#mytable").append(tr+td0+td1+td2+td3+td4); 

						}							
					}else{

						document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
					}
				}else{

					document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
				}

			}
		});

	}

});



$(document).ready(function() {
	var obj1;
	$(window).trigger('setup');
	


	$('#mytable').delegate("a", "click", function(){

		if($(this).children().val()=='File Name'){
			if($('#status').attr("title")=="Connected"){
				$("#mytable").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'NAME'},
					async: true,
					cache: false,

					success:function(data){

						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
								$("#mytable").append(thead+trhead+tbody); 

								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");
									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2); 

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[1]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[0]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[1]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[0]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										if(objSingle[1]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='odd'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[0]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[1]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='odd'>"+objSingle[0]+"</td>";
										}
										

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytable").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{

								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}

						}else{

							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						}

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		}else if($(this).children().val()=='Last Modified Date'){

			if($('#status').attr("title")=="Connected"){
				$("#mytable").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'DATE'},
					async: true,
					cache: false,

					success:function(data){
						//alert(data);

						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
								$("#mytable").append(thead+trhead+tbody); 



								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");
									
									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										if(objSingle[2]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='odd'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='odd'>"+objSingle[1]+"</td>";
										}
										

										var td2="<td class='odd'>"+objSingle[0]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytable").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{

								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{

							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						}

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}



		}else if($(this).children().val()=='Last Modified Time'){

			if($('#status').attr("title")=="Connected"){
				$("#mytable").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'TIME'},
					async: true,
					cache: false,

					success:function(data){
						
						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
								$("#mytable").append(thead+trhead+tbody); 

                                for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");
									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);
									

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[3]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										if(objSingle[3]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='odd' ><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[3]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='odd' >"+objSingle[1]+"</td>";
										}
										

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[0]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytable").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{
								
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}

										}else{

								 document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
							 }

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}





		}else if($(this).children().val()=='Size'){


			if($('#status').attr("title")=="Connected"){
				$("#mytable").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'SIZE'},
					async: true,
					cache: false,

					success:function(data){
						
						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
								$("#mytable").append(thead+trhead+tbody); 

                                for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");
									
									var objsize = objSingle[0]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[4]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[4]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										if(objSingle[4]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='odd'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[4]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='odd'>"+objSingle[1]+"</td>";
										}
										

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytable").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{
								
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}

						}else{

							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						}

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}






		}else if($(this).children().val()=='Type'){



			if($('#status').attr("title")=="Connected"){
				$("#mytable").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/','sort':'TYPE'},
					async: true,
					cache: false,

					success:function(data){
						
						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
								$("#mytable").append(thead+trhead+tbody); 



								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");
									
									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[0]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[2]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										if(objSingle[0]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='odd'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[0]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='odd'>"+objSingle[1]+"</td>";
										}
										

										var td2="<td class='odd'>"+objSingle[2]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytable").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{
								
								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{

								 document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
							 }

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}


		}else{
			var dir = $(this).children().val();
			//alert("Selected Dir :"+dir);
			apkpath = dir;
			if($('#status').attr("title")=="Connected"){
				$("#mytable").empty(); 

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsFEX",
					data:{'dir':'/data/app/'+dir+'/','sort':'DATE'},
					async: true,
					cache: false,

					success:function(data){
						//alert(data);

						var obj=$.parseJSON(data);

						obj1=obj;

						if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
							if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
								var thead="<thead>";
								var tbody="<tbody>";
								var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
								$("#mytable").append(thead+trhead+tbody); 



								for(var i=0;i < obj.length;i++)
								{
									var objSingle=obj[i].split("\t");
									
									var objsize = objSingle[4]/1024;
									var filesize = objsize/1024;
									var finalSize = filesize.toFixed(2);

									if(i%2==0){
										var tr="<tr class='awesome'>";

										if(objSingle[2]=='Dir'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
										}

										

										var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
										var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
										var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
									}else{
										var tr="<tr class='awesome'>";

										if(objSingle[2]=='Dir'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
											var td1="<td class='odd'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[2]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
										}else if(objSingle[2]=='File'){
											var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
											var td1="<td class='odd'>"+objSingle[1]+"</td>";
										}
										

										var td2="<td class='odd'>"+objSingle[0]+"</td>";
										var td3="<td class='odd'>"+objSingle[3]+"</td>";
										var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
									}
									$("#mytable").append(tr+td0+td1+td2+td3+td4); 

								}							
							}else{

								document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
							}
						}else{

							document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						}

					}
				});



			}else{
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
			
			
			
		}


	});
	$('#mytable').delegate("button", "click", function(){

		
		var sub1=$(this).val();

		if(sub1.indexOf('.apk') != -1){
			var filename=$(this).val();
			//alert("filename :"+filename);
			if($('#status').attr("title")=="Connected"){	

				$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsOP",
					data:{'dir':'/data/app/'+apkpath+'/'+filename,'filename':filename,'action':'blackboxdownloadapp'},
					async: true,
					cache: false,
					
					success:function(data){	

						var obj=$.parseJSON(data);
						var items = [];
						$.each(obj, function( key, val ) {
							if(key=='msg'){
								valiCloseAll1();
								PF('msg').renderMessage({"summary":"",
									"detail":val,
									"severity":"info"});
								document.getElementById('unepop').innerHTML = val;


							}

						}); 


					},
					error:function(data){

						document.getElementById('unepop').innerHTML = "Error! Requested APK file could not be downloaded. Please try again.";
						valiCloseAll1();
					}
				});

				
			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
				valiCloseAll1();

			}


		}
		else{
			
			PF('msg').renderMessage({"summary":"Warning!",
				"detail":"No APK file selected. Please select APK file and try again.",
				"severity":"info"});
			document.getElementById('unepop').innerHTML = "Warning! No APK file selected. Please select APK file and try again.";
		}






	});


	$('#refresh').click(function(event){
		$('#searchData').val("");
		document.getElementById('unepop').innerHTML = "";
		if($('#status').attr('title')==('Connected')){
			$("#showdbname").text("");
			
			$("#mytable").show();
			$('#mytable').empty();


			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsFEX",
				data:{'dir':'/data/app/','sort':'DATE'},
				async: true,
				cache: false,

				success:function(data){
				
					var obj=$.parseJSON(data);

					obj1=obj;

					if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){
						
						if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931" && obj[1]!="Invalid_Command_Received_931"){
							
							var thead="<thead>";
							var tbody="<tbody>";
							var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input type='text' value='Size'></input></a></th>";
							$("#mytable").append(thead+trhead+tbody); 



							for(var i=0;i < obj.length;i++)
							{
								var objSingle=obj[i].split("\t");
								
								var objsize = objSingle[4]/1024;
								var filesize = objsize/1024;
								var finalSize = filesize.toFixed(2);

								if(i%2==0){
									var tr="<tr class='awesome'>";

									if(objSingle[2]=='Dir'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										var td1="<td class='even' style='width:20%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
									}else if(objSingle[2]=='File'){
										var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
										var td1="<td class='even' style='width:20%;'>"+objSingle[1]+"</td>";
									}

									

									var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
									var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
									var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
								}else{
									var tr="<tr class='awesome'>";

									if(objSingle[2]=='Dir'){
										var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
										var td1="<td class='odd'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
									}else if(objSingle[2]=='File'){
										var td0="<td style='width:50px; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
										var td1="<td class='odd'>"+objSingle[1]+"</td>";
									}
									

									var td2="<td class='odd'>"+objSingle[0]+"</td>";
									var td3="<td class='odd'>"+objSingle[3]+"</td>";
									var td4="<td class='odd'>"+finalSize+" MB</td></tr>";
								}
								$("#mytable").append(tr+td0+td1+td2+td3+td4); 

							}							
						}else{
							
							document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						}

									}else{

							 document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
						 }

				}
			});

		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";

		}

	});
	var check="";


	$("#searchData").keypress(function(e) {
		 if(e.which == 13) {
		vali();
		document.getElementById('unepop').innerHTML = "";
		if(searchCheck=="Start"){

			document.getElementById('unepop').innerHTML = "";
			if($('#status').attr("title")=="Connected"){
				var search=$('#searchData').val();
				var recent=$('#ip1').val();
				var pattern=/^[a-zA-Z0-9- ._/]+$/;
				if(search!="" && search!=null && pattern.test(search) == true){
					searchCheck="in process";
					$('#mytable').empty();
					
					$('#mytable').css({'display':'block'});
					var searchStatus="";
					$.ajax({
						type:"POST",
						url:"http://"+window.location.host+"/VMastsFEX",
						data:{'dir':'/data/app/','sort':'DATE'},
						async: true,
						cache: false,
						datatype:"json",
						success:function(data){

							var obj=$.parseJSON(data);
							if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

								if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){

									var thead="<thead>";
									var tbody="<tbody>";
									var trhead="<tr style='background-color:#d3eced;height:30px;'><th style='text-align:center; width:7%;'><input readonly type='text' value='Select'></input></th><th style='text-align:center; width:40%;'><a href='#'><input readonly type='text' value='File Name'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input readonly type='text' value='Last Modified Date'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input readonly type='text' value='Last Modified Time'></input></a></th><th style='text-align:center; width:20%;'><a href='#'><input readonly type='text' value='Size'></input></a></th>";
									$("#mytable").append(thead+trhead+tbody); 
									obj.sort();
									for(var i=0;i < obj.length;i++)
									{
										var objSingle=obj[i].split("\t");

										var objsize = objSingle[4]/1024;
										var filesize = objsize/1024;
										var finalSize = filesize.toFixed(2);
										
										if(objSingle[1].toLowerCase().indexOf(search.toLowerCase())>=0){

											
												var tr="<tr class='awesome'>";

												if(objSingle[2]=='Dir'){
													var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><img src='images/dir-2.png' width='15' height='15' style='margin-left: 30%;'/></td>";
													var td1="<td class='even' style='width:40%;'><a href='#' class='atag'><input readonly type='text' value='"+objSingle[1]+"' title='"+objSingle[0]+"' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
												}else if(objSingle[2]=='File'){
													var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center'><button value='"+objSingle[1]+"' type='button' onclick='vali();' class='down_button'></button></td>";
													var td1="<td class='even' style='width:40%;'>"+objSingle[1]+"</td>";
												}

												
		 
												var td2="<td class='even' style='width:20%;'>"+objSingle[0]+"</td>";
												var td3="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
												var td4="<td class='even' style='width:20%;'>"+finalSize+" MB</td></tr>";
											
											$("#mytable").append(tr+td0+td1+td2+td3+td4); 
											searchStatus="success";
										}else{
											
										}
									}

									if(searchStatus=="success"){

										document.getElementById('unepop').innerHTML = "Search completed! Application APK file(s) found.";
									}else{
										$("#mytable").empty();
										document.getElementById('unepop').innerHTML = "Search completed! Application APK file(s) not found.";
									}
									searchCheck="Start";
									valiCloseAll1();
									
								}else {
									valiCloseAll1();
									document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
								}
							}else{
								valiCloseAll1();
								document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";

							}
						}
					});

				}else{
					valiCloseAll1();
					$('#mytable').empty();
					
					document.getElementById('unepop').innerHTML = " Sorry! Could not perform search operation. Please input valid data and try again.";
					
				}
			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
			}
		
		}
		 }
	});
});
function vali()
{
	$('#overlay').fadeIn('fast',function(){
		$('#box').show();
		$('#box').animate({'top':'35%'},500);
	});
}
function valiCloseAll1(){
	var $j5 = jQuery.noConflict();
	$j5('#overlay').fadeOut('fast',function(){
		$j5('#box').hide();
	});
}