jQuery.noConflict();

var checkStatusdb=0;
var dbname;
var oldData;
var tableNameSelect="";
$(window).bind('setup', function() {

	function update() {
		
		if($('#status').attr('title')=="Connected"){
			if(parseInt(checkStatusdb)==0){
				document.getElementById('unepop').innerHTML = "";
				execute();
				
			}
		}else{
			checkStatusdb=0;
			valiCloseDB();
			
		}
		
	
	}


	setInterval(update, 500);
	update();

	function execute(){
		
		 document.getElementById('unepop').innerHTML = "Please select the database.";
		checkStatusdb=parseInt(checkStatusdb)+1;
		vali();
		$('#apknamelabel').text("");
		$('#dbnamelabel').text("");
		$.ajax({
			type:"POST",
			url:"http://"+window.location.host+"/VMastsDBE",
			data:{'dir':'/data/data/','sort':'TYPE'},
			async: true,
			cache: false,

			success:function(data){
				document.getElementById('unepop').innerHTML = "Please select the database.";
				var obj=$.parseJSON(data);

				$("#ip1").val("/data/data");
			
				if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

					if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){
						var thead="<thead>";
						var tbody="<tbody>";
						var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:43%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:10%;'><label>Size</label></th>";
						$("#mytabledb").append(thead+trhead+tbody); 

						for(var i=0;i < obj.length;i++)
						{
							var objSingle=obj[i].split("\t");
							
							var objsize = objSingle[2]/1024;
							var filesize = objsize/1024;
							var finalSize = filesize.toFixed(2);
							
                            var len=objSingle[1].length;
							var ext=objSingle[1].substring(len-3,len);
						
								if(i%2==0){
									var tr="<tr class='awesome'>";
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center;'><button value='"+objSingle[0]+"' type='button' title='"+objSingle[1]+"' class='down_db'></button></td>";
									var td1="<td class='even' style='width:43%;'>"+objSingle[0]+"</td>";
									var td2="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
									var td3="<td class='even' style='width:20%;'>"+objSingle[4]+"</td>";
									var td4="<td class='even' style='width:10%;'>"+finalSize+" MB</td></tr>";
								}else{
									var tr="<tr class='awesome'>";

									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center;'><button value='"+objSingle[0]+"' type='button' title='"+objSingle[1]+"' class='down_db'></button></td>";					
									var td1="<td class='odd' style='width:43%;'>"+objSingle[0]+"</td>";

									var td2="<td class='odd' style='width:20%;'>"+objSingle[3]+"</td>";
									var td3="<td class='odd' style='width:20%;'>"+objSingle[4]+"</td>";
									var td4="<td class='odd' style='width:10%;'>"+finalSize+" MB</td></tr>";
								}
						
							$("#mytabledb").append(tr+td0+td1+td2+td3+td4);
							valiCloseDB();

						}   

					}else {
						
						document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						
					}
				}else{
					valiCloseDB();
					alert("Database Not Exist!!");
					
				}
			}
		});
		
	}

});

$(document).ready(function() {
	var obj1;
	$(window).trigger('setup');

	$('#light').css("display","none");
	$('#fade').css("display","none"); 


	$('#refresh').click(function(event){
		$('#dbnamelabel').text("");
		$('#mydb').empty();
		$('#mydb').css("display","none"); 
		$("#table").show();
		$("#mytabledb").css("display","block");
		$("#mytabledb").empty();

		document.getElementById('unepop').innerHTML = "";
		
		vali();
		$.ajax({
			type:"POST",
			url:"http://"+window.location.host+"/VMastsDBE",
			data:{'dir':'/data/data/','sort':'TYPE'},
			async: true,
			cache: false,

			success:function(data){

				var obj=$.parseJSON(data);

				$("#ip1").val("/data/data");
				
				if(obj!="" && obj!=undefined && obj.length>=1 && obj[0].indexOf("Please Send Valid Command!") == -1){

					if( obj[1]!="Re_LoginRequiredOnDevice" && obj[0]!="Invalid_Command_Received_931"){
						var thead="<thead>";
						var tbody="<tbody>";
						var trhead="<tr style='background-color:#d3eced;height:30px; border:1px solid #bbb;'><th style='width:7%; text-align:center;border:1px solid #bbb;'><label>Select</label></th><th style='text-align:center; border:1px solid #bbb; width:43%;'><label>File Name</label></th><th style='text-align:center;border:1px solid #bbb; width:20%;'><label>Last Modified Date</label></th><th style='text-align:center; width:20%; border:1px solid #bbb;'><label>Last Modified Time</label></th><th style='text-align:center;border:1px solid #bbb; width:10%;'><label>Size</label></th>";
						$("#mytabledb").append(thead+trhead+tbody); 

						for(var i=0;i < obj.length;i++)
						{
							var objSingle=obj[i].split("\t");
							
							var objsize = objSingle[2]/1024;
							var filesize = objsize/1024;
							var finalSize = filesize.toFixed(2);
							
						
                            var len=objSingle[1].length;
							var ext=objSingle[1].substring(len-3,len);
							
								if(i%2==0){
									var tr="<tr class='awesome'>";
									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center;'><button value='"+objSingle[0]+"' type='button' title='"+objSingle[1]+"' class='down_db'></button></td>";
									var td1="<td class='even' style='width:43%;'>"+objSingle[0]+"</td>";
									var td2="<td class='even' style='width:20%;'>"+objSingle[3]+"</td>";
									var td3="<td class='even' style='width:20%;'>"+objSingle[4]+"</td>";
									var td4="<td class='even' style='width:10%;'>"+finalSize+" MB</td></tr>";
								}else{
									var tr="<tr class='awesome'>";

									var td0="<td style='width:7%; border:1px solid #BBBBBB; text-align:center;'><button value='"+objSingle[0]+"' type='button' title='"+objSingle[1]+"' class='down_db'></button></td>";					
									var td1="<td class='odd' style='width:43%;'>"+objSingle[0]+"</td>";

									var td2="<td class='odd' style='width:20%;'>"+objSingle[3]+"</td>";
									var td3="<td class='odd' style='width:20%;'>"+objSingle[4]+"</td>";
									var td4="<td class='odd' style='width:10%;'>"+finalSize+" MB</td></tr>";
								}
						
							$("#mytabledb").append(tr+td0+td1+td2+td3+td4);
							
							
						}   
						valiCloseDB();
						$('#viewstructure').css({'display':'none'});
						$('#viewtable').css({'display':'none'});
						$('#insert').css({'display':'none'});
						$('#update1').css({'display':'none'});
						$('#delete').css({'display':'none'});
						$('#push').css({'display':'none'});
					}else {
						
						document.getElementById('unepop').innerHTML = "Your login session has expired! Please check device login or try refreshing the page.";
						
					}
				}else{
					alert("DataBase Not Exist!!");
					
					document.getElementById('unepop').innerHTML = "Error fetching APK files! Please check device connection or try refreshing the page.";
					valiCloseDB();
				}
			}
		});
		

		
	});

	var check="";


	$('#mytabledb').delegate("button", "click", function(){
		document.getElementById('unepop').innerHTML = "";

		$('#msg').hide();

		//Sort....
				if($('#status').attr('title')==('Connected')){
					
					var filename=$(this).val();
					var attr1=$(this).attr('title');
					dbname=filename;
						if (confirm('Do you want to view '+dbname+' database?')) {

							vali();
							
							if(attr1!="" && attr1!=undefined && filename!="" && filename!=undefined){
								$('#showdbname').text(filename);
								$('#ip1').val($('#ip1').val()+"/"+filename);
								$.ajax({
									type:"POST",
									url:"http://"+window.location.host+"/VMastsDDF",
									data:{'attr':attr1,'filename':filename},
									async: true,
									cache: false,

									success:function(data){
										var obj=$.parseJSON(data);
										var items = [];
										$.each( obj, function( key, val ) {

											
											
											if(key=='msg'){

												
												document.getElementById('unepop').innerHTML = val;
												
												$('#viewstructure').css({'display':'block'});
												$('#viewtable').css({'display':'none'});
												$('#insert').css({'display':'none'});
												$('#update1').css({'display':'none'});
												$('#delete').css({'display':'none'});
												$('#push').css({'display':'none'});
												$('#dbName').css({'display':'block'});
												
												document.getElementById('unepop').innerHTML = "Please click on VIEW TABLE'S to proceed!";

												valiCloseDB();
											}else
											if(key='apkName'){
												$('#viewstructure').css({'display':'block'});
												$('#viewtable').css({'display':'none'});
												$('#insert').css({'display':'none'});
												$('#update1').css({'display':'none'});
												$('#delete').css({'display':'none'});
												$('#push').css({'display':'none'});
												$('#dbName').css({'display':'block'});
												$('#apknamelabel').text("APK Name: "+val);
												$('#dbnamelabel').text("DB File: "+filename);
												valiCloseDB();
											}
										}); 
										
										valiCloseDB();
									}
								});

								$('#viewdb').show();
								$('#mytabledb').hide();
							}else{
							document.getElementById('unepop').innerHTML = "Warning! No APK file selected. Please select APK file and try again.";
								valiCloseDB();	
							}
						}
					
				}else{
					document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";

				}


	});

	$('#viewstructure').click(function(){
		document.getElementById('unepop').innerHTML = "Please select the table name to view data/records.";

		$('#viewtable').css({'display':'none'});
		$('#insert').css({'display':'none'});
		$('#update1').css({'display':'none'});
		$('#delete').css({'display':'none'});
		$('#push').css({'display':'none'});
		$('#viewstructure').css({'display':'none'});

		var path=$('#ip1').val();
		var dbname=path.substring(path.lastIndexOf("/")+1,path.length);
	
		if(dbname!="" && dbname!=undefined){
			if($('#status').attr('title')==('Connected')){

			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsDBEX",
				data:{'command':'select','attr':dbname,'filename':'sss'},
				async: true,
				cache: false,
				datatype:"json",
				success:function(data){

					var obj=data;
					
					$.each( obj, function( key, val ) {
						if(key=="msg"){

							PF('msgdb').renderMessage({"summary":"",
			                    "detail":val,
			                    "severity":"info"});
						}

					});
					$.each( obj, function( key, val ) {
						if(key=="exception"){

							//alert(val);
							PF('msgdb').renderMessage({"summary":"",
			                    "detail":val,
			                    "severity":"info"});
						}

					});

					var name="";
					var schema;
					$.each( obj, function( key, val ) {
						if(key=="name"){
							name=val;
											
						}else if(key=="schema"){
							schema=val;
							
						}

					});
					$("#tablecopy").show();
					$("#mydb").show();
					$("#mydb").empty();
					var statusTable="start";
					var th="<tr style='background-color:#d3eced;height:30px;'><th>Name</th><th>Schema</th></tr>"
						$("#mydb").append(th);
					for(var j=0;j < name.length;j++)
					{
						var tr="<tr class='awesome'>";
						var td0="<td><a href='#' class='atag'><input readonly type='text' value='"+name[j]+"' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></a></td>";
						var td1="<td><a href='#' class='atag'><textarea rows='5' cols='60' readonly='readonly'> Name:"+name[j]+",Schema: "+schema[j]+"</textarea></a></td>";
						$("#mydb").append(tr+td0+td1);
						statusTable="success";
					}

					if(name.length<0 ||statusTable=="start" || statusTable!="success"){
						document.getElementById('unepop').innerHTML = " Warning! Database is empty. Please go back and select different database.";
					}
					
					$('#table').hide();
					$('#viewstructure').css({'display':'none'});

				}
			});
			}else{
				
				document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
				
			}


		}else{
			
			document.getElementById('unepop').innerHTML = "Warning! No APK file selected. Please select APK file and try again.";
		}

	});


	$('#mydb').delegate("a", "click", function(){
		document.getElementById('unepop').innerHTML = "Please click on VIEW TABLE VALUE(S) to proceed.";
		$('#viewstructure').css({'display':'block'});
		var path=$('#ip1').val();
		var dbname=path.substring(path.lastIndexOf("/")+1,path.length);
		var tablename=$(this).children().val();
		if(tablename.indexOf('CREATE TABLE')>=0){
			tablename=tablename.substring(tablename.indexOf(':')+1,tablename.indexOf(','));
		}
		tableNameSelect=tablename;
		if(dbname!="" && dbname!=undefined && tablename!=""  && tablename!=undefined){

			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsDBEX",
				data:{'command':'selectTables','attr':dbname,'tablename':tablename},
				async: true,
				cache: false,
				datatype:"json",
				success:function(data){

					var obj=data;

					$.each( obj, function( key, val ) {
						if(key=="msg"){
							document.getElementById('unepop').innerHTML = " ";
							PF('msgdb').renderMessage({"summary":"Success!",
			                    "detail":val,
			                    "severity":"info"});
						}

					});
					$.each( obj, function( key, val ) {
						if(key=="exception"){
							document.getElementById('unepop').innerHTML = " ";
							PF('msgdb').renderMessage({"summary":" ",
			                    "detail":val,
			                    "severity":"info"});
						}

					});
					var field;
					var type;
					var notnull;
					var default_value;
					var pk;
					$.each( obj, function( key, val ) {
						if(key=="field"){
							field=val;
						}else if(key=="notnull"){
							notnull=val;
					
						}else if(key=="type"){
							type=val;
					
						}else if(key=="default_value"){
							default_value=val;
					
						}else if(key=="pk"){
							pk=val;
					
						}

					});

					
					$("#mydb").empty();
					$("#mydb").attr('name',tablename);
					var th="<tr style='background-color:#d3eced;height:30px;'><th>Field</th><th>Type</th><th>Not Null</th><th>Default Values</th><th>Primary Key</th></tr>";
						$("#mydb").append("<tr style='background-color:#9EC9D4;height:30px;border-style: solid;border-width: 2px;'><th class='opt' title='Table Name' colspan='5' style='text-align: center;'>Current Table: "+tablename+"</th></tr>");
						$("#mydb").append(th);
					
					for(var j=0;j < field.length;j++)
					{

						var tr="<tr class='awesome'>";
						var td0="<td><input readonly type='text' readonly='readonly' value='"+field[j]+"' style='border:0px;height:auto;padding: 0px;'></input></td>";
						var td1="<td><input readonly type='text' readonly='readonly' value='"+type[j]+"' style='border:0px;height:auto;padding: 0px;' ></input></td>";
						var td2="<td><input readonly type='text' value='"+notnull[j]+"' readonly='readonly' style='border:0px;height:auto;padding: 0px;' ></input></td>";
						var td3="<td><input readonly type='text' value='"+default_value[j]+"' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></td>";
						var td4="<td><input readonly type='text' value='"+pk[j]+"' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></td></tr>";
						$("#mydb").append(tr+td0+td1+td2+td3+td4); 
					}


				},
				error:function(){
					//alert("Error");
					
					document.getElementById('unepop').innerHTML = "Error! Database table(s) could not be retrieved. Please try again.";
				}
			});


			$('#viewtable').css({'display':'block'});

			$('#viewdbvalues').show();
			$('#viewdb').hide();
			$('#table').hide();
		}else{
			
			document.getElementById('unepop').innerHTML = "Error! No database table selected. Please try again.";
		}




	});
	


	$('#viewtable').click(function(){
		 document.getElementById('unepop').innerHTML = "Please select desired action(s).";
		$('#viewtable').css({'display':'block'});
		$('#insert').css({'display':'none'});
		$('#update1').css({'display':'none'});
		$('#delete').css({'display':'none'});
		$('#push').css({'display':'none'});
		$('#viewstructure').css({'display':'none'});

		var path=$('#ip1').val();
		var dbname=path.substring(path.lastIndexOf("/")+1,path.length);

		var tablename=tableNameSelect;
		var rowcount=0;
		var rows={};
		var field;
		var obj;

		if(dbname!="" && dbname!=undefined && tablename!="" && tablename!=undefined){
			
			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsDBEX",
				data:{'command':'selectTableValues','attr':dbname,'tablename':tablename},
				async: true,
				cache: false,
				datatype:"json",
				success:function(data){


					var obj=JSON.stringify(data);
					
					obj=JSON.parse(obj);
			
			

					$.each( data, function( key, val ) {

						if(key=="rowCount"){
							rowcount=val;					
						}
					});

					if(rowcount>=1){
						$.each( data, function( key, val ) {
							if(key=="field"){
								field=val;				
							}
						});

						$("#mydb").empty();

						$("#mydb").attr('name',tablename);
						var th="<th>"+field[0]+"</th>";
						for(var k=1;k<field.length;k++){
							th=th+"<th>"+field[k]+"</th>";
						}
						$("#mydb").append("<tr style='background-color:#9EC9D4;height:30px;border-style: solid;border-width: 2px;'><th class='opt' title='Table Name' colspan="+(field.length+1)+" style='text-align: center;'>Current Table: "+tablename+"</th></tr>");
						$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"<th class='opt' style='display:none'>Action</th></tr>");


						var td;
						var s1="";
						var ii=1;
						$.each( obj, function( key, val ) {
							for(var ii=1;ii<rowcount;ii++){
								
								if(key=="row"+ii){						
									
									td=td+"<tr id='r"+ii+"'>";
									for(var j=0;j < val.length;j++)
									{
										var len=parseInt(val[j].length);
										if(isNaN(len)){
											len=12;
										}
										td=td+"<td><input readonly type='text' class='edit_row"+ii+"' value='"+val[j]+"' size='"+len+"' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></td>";
										s1="success";
									}
									if(s1=="success"){
										td=td+"<td  class='btndelete' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Delete</button></td>";
										td=td+"<td class='btn' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Edit</button></td></tr>";
											
									}else{
										
									}
									ii=ii+1;
								}
							}
						});
						$("#mydb").append(td);

					}else{
						
						document.getElementById('unepop').innerHTML = "Selected database table is empty!";

						$.each( data, function( key, val ) {
							if(key=="field"){
								field=val;				
							}
						});

						$("#mydb").empty();
						$("#mydb").attr('name',tablename);
						var th="<th>"+field[0]+"</th>";
						for(var k=1;k<field.length;k++){
							th=th+"<th>"+field[k]+"</th>";
						}
						$("#mydb").append("<tr style='background-color:#9EC9D4;height:30px;border-style: solid;border-width: 2px;'><th class='opt' title='Table Name' colspan="+(field.length+1)+" style='text-align: center;'>Current Table: "+tablename+"</th></tr>");
						$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"<th class='opt' style='display:none'>Action</th></tr>");
					}
				}
			});

		
			$('#table').hide();

			$('#viewtable').css({'display':'none'});
			$('#insert').css({'display':'block'});
			$('#update1').css({'display':'block'});
			$('#delete').css({'display':'block'});
			$('#push').css({'display':'block'});
			$('#viewstructure').css({'display':'block'});
		}else{
			
			document.getElementById('unepop').innerHTML = "Error! No database table selected. Please try again.";
		}
	});

	$('#selectTable').change(function(){
		document.getElementById('unepop').innerHTML = "";
	
		var path=$('#ip1').val();
		var dbname=path.substring(path.lastIndexOf("/")+1,path.length);
	
		var tablename=tableNameSelect;
		var rowcount;
		var rows={};
		var field;
		var obj;

		if(dbname!="" && dbname!=undefined && tablename!=""  && tablename!=undefined){

			$.ajax({
				type:"POST",
				url:"http://"+window.location.host+"/VMastsDBEX",
				data:{'command':'selectTableValues','attr':dbname,'tablename':tablename},
				async: true,
				cache: false,
				datatype:"json",
				success:function(data){
					var obj=data;
					obj=JSON.stringify(data);

					$.each( data, function( key, val ) {
						if(key=="rowCount"){
							rowcount=val;					
						}
					});

					$.each( data, function( key, val ) {
						if(key=="msg"){
							PF('msgdb').renderMessage({"summary":"",
			                    "detail":val,
			                    "severity":"info"});
						}

					});
					$.each( data, function( key, val ) {
						if(key=="exception"){
							PF('msgdb').renderMessage({"summary":"",
			                    "detail":val,
			                    "severity":"info"});
						}

					});
					if(rowcount>2){
						$.each( data, function( key, val ) {
							if(key=="field"){
								field=val;				
							}
						});

						$("#mydb").empty();

						$("#mydb").attr('name',tablename);
						var th="<th>"+field[0]+"</th>";
						for(var k=1;k<field.length;k++){
							th=th+"<th>"+field[k]+"</th>";
						}
						$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");
						var td;
						var ii=1;
						$.each( data, function( key, val ) {
							for(var ii=1;ii<rowcount;ii++){
								if(key=="row"+ii){						
									td=td+"<tr id='r"+ii+"'>";
									for(var j=0;j < val.length;j++)
									{
										var len=parseInt(val[j].length);
										if(isNaN(len)){
											len=12;
										}
										td=td+"<td><input readonly type='text' class='edit_row"+ii+"' value='"+val[j]+"' size='"+len+"px' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></td>";
									}
									td=td+"<td class='btndelete' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Delete</button></td>";
									td=td+"<td class='btn' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Edit</button></td></tr>";
									ii=ii+1;
								}
							}
						});
						$("#mydb").append(td);

					}else{
						
						document.getElementById('unepop').innerHTML = "Selected database table is empty!";

						$.each( data, function( key, val ) {
							if(key=="field"){
								field=val;				
							}
						});

						$("#mydb").empty();

						$("#mydb").attr('name',tablename);
						var th="<th>"+field[0]+"</th>";
						for(var k=1;k<field.length;k++){
							th=th+"<th>"+field[k]+"</th>";
						}
						$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");
					}
				}
			});

			$('#table').hide();
		}else{
			PF('msgdb').renderMessage({"summary":"",
                "detail":"Select DbName or Table name",
                "severity":"info"});
		}
	});

	$('#mydb').delegate("button", "click", function(){

		document.getElementById('unepop').innerHTML = "";
		var path=$('#ip1').val();
		var tablename=$("#mydb").attr('name');
		var text=$(this).text();
		var id=$(this).attr('id');
		var valueOld="edit_"+id;
		if(text=='Edit'){
			oldData="Start";
			$("."+valueOld).each(function () {
				oldData=oldData+"##"+$(this).val();

			});

			$('.btn').children().each(function () {
				var btnValue=$(this).attr('id');

				if(btnValue!=id){
					$(this).text('Edit');
					$(".edit_"+btnValue).attr("readonly", "readonly");
					$(".edit_"+btnValue).css({'background-color':'','color':'','height':'','cursor':'pointer','text-decoration':''});

				}
			});
			$(this).text('Update');
			$(".edit_"+id).attr("readonly", false);
			$(".edit_"+id).css({'background-color':'grey','color':'white','height':'30px','cursor':'','text-decoration':'none'});



		}else if(text=='Update'){
			var value="edit_"+id;
			var data="Start";
			$("."+value).each(function () {
				data=data+"##"+$(this).val()
			});

			if(dbname!="" && dbname!=undefined && tablename!=""  && tablename!=undefined && data!="" && data!="Start" && data!=undefined && oldData!="" && oldData!=undefined){
				/*$.post("http://"+window.location.host+"/VMastsDBEX",{'command': 'update','attr':dbname,'tablename':tablename,'data':data,'olddata':oldData },function(data){
*/
				
				$.post("http://"+window.location.host+"/VMastsDBEX",{'command': 'update','attr':dbname,'tablename':tablename,'data':data,'olddata':oldData },function(data){
					
				
					$.each( data, function( key, val ) {
				
						if(val=="Updated"){
				
							document.getElementById('unepop').innerHTML = "Values updated successfully!";
							$.ajax({
								type:"POST",
								url:"http://"+window.location.host+"/VMastsDBEX",
								data:{'command':'selectTableValues','attr':dbname,'tablename':tablename},
								async: true,
								cache: false,
								datatype:"json",
								success:function(data){
									var obj=data;
									obj=JSON.stringify(data);
									
									$.each( data, function( key, val ) {
										
										if(key=="rowCount"){
											rowcount=val;					
										}
									});

									if(rowcount>2){
										$.each( data, function( key, val ) {
											if(key=="field"){
												field=val;				
											}
										});

										$("#mydb").empty();

										$("#mydb").attr('name',tablename);
										var th="<th>"+field[0]+"</th>";
										for(var k=1;k<field.length;k++){
											th=th+"<th>"+field[k]+"</th>";
										}
										$("#mydb").append("<tr style='background-color:#9EC9D4;height:30px;border-style: solid;border-width: 2px;'><th class='opt' title='Table Name' colspan="+(field.length+1)+" style='text-align: center;'>Current Table: "+tablename+"</th></tr>");
										$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");


										var td;
										var ii=1;
										$.each( data, function( key, val ) {
											for(var ii=1;ii<rowcount;ii++){

												if(key=="row"+ii){						
												
													td=td+"<tr id='r"+ii+"'>";
													for(var j=0;j < val.length;j++)
													{
														var len=parseInt(val[j].length);
														if(isNaN(len)){
															len=12;
														}
														td=td+"<td><input readonly type='text' class='edit_row"+ii+"' value='"+val[j]+"' size='"+len+"px' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></td>";
													}
													td=td+"<td class='btndelete' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Delete</button></td>";
													td=td+"<td class='btn' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Edit</button></td></tr>";
													
													ii=ii+1;
												}

											}
										});

										$("#mydb").append(td);
									}else{
										document.getElementById('unepop').innerHTML = "Selected database table is empty!";
										$.each( data, function( key, val ) {
											if(key=="field"){
												field=val;				
											}
										});

										$("#mydb").empty();

										$("#mydb").attr('name',tablename);
										var th="<th>"+field[0]+"</th>";
										for(var k=1;k<field.length;k++){
											th=th+"<th>"+field[k]+"</th>";
										}
										$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");
									}
								}
							});

						}else{
						
						
							document.getElementById('unepop').innerHTML = "Warning! Please input valid data.";
						}
					});
				});
				
			}else{
				
				document.getElementById('unepop').innerHTML = "Error! Update failed. Please input valid data.";
			}
		}else if(text=='Insert'){

			var value="edit_"+id;
			var data="Start";

			$("."+value).each(function () {

				data=data+"##"+$(this).val();

			});
			if(dbname!="" && dbname!=undefined && tablename!=""  && tablename!=undefined && data!="" && data!="Start" && data!=undefined){
				$.post("http://"+window.location.host+"/VMastsDBEX",{'command': 'insert','attr':dbname,'tablename':tablename,'data':data },function(data){
					
					
					$.each( data, function( key, val ) {
						if(val=="Inserted"){
							document.getElementById('unepop').innerHTML = "Values inserted successfully!";
							$.ajax({
								type:"POST",
								url:"http://"+window.location.host+"/VMastsDBEX",
								data:{'command':'selectTableValues','attr':dbname,'tablename':tablename},
								async: true,
								cache: false,
								datatype:"json",
								success:function(data){
									var obj=data;
									obj=JSON.stringify(data);
									
									$.each( data, function( key, val ) {
										
										if(key=="rowCount"){
											rowcount=val;					
										}
									});

									if(rowcount>2){
										$.each( data, function( key, val ) {
											if(key=="field"){
												field=val;				
											}
										});

										$("#mydb").empty();

										$("#mydb").attr('name',tablename);
										var th="<th>"+field[0]+"</th>";
										for(var k=1;k<field.length;k++){
											th=th+"<th>"+field[k]+"</th>";
										}

										$("#mydb").append("<tr style='background-color:#9EC9D4;height:30px;border-style: solid;border-width: 2px;'><th class='opt' title='Table Name' colspan="+(field.length+1)+" style='text-align: center;'>Current Table: "+tablename+"</th></tr>");
										$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");


										var td;
										var ii=1;
										$.each( data, function( key, val ) {
											for(var ii=1;ii<rowcount;ii++){

												if(key=="row"+ii){						
												
													td=td+"<tr id='r"+ii+"'>";
													for(var j=0;j < val.length;j++)
													{
														var len=parseInt(val[j].length);
														if(isNaN(len)){
															len=12;
														}
														td=td+"<td><input readonly type='text' class='edit_row"+ii+"' value='"+val[j]+"' size='"+len+"px' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></td>";
													}
													td=td+"<td class='btndelete' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Delete</button></td>";
													td=td+"<td class='btn' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Edit</button></td></tr>";
													
													ii=ii+1;
												}

											}
										});

										$("#mydb").append(td);
									}else{
										document.getElementById('unepop').innerHTML = "Selected database table is empty!";
										$.each( data, function( key, val ) {
											if(key=="field"){
												field=val;				
											}
										});

										$("#mydb").empty();

										$("#mydb").attr('name',tablename);
										var th="<th>"+field[0]+"</th>";
										for(var k=1;k<field.length;k++){
											th=th+"<th>"+field[k]+"</th>";
										}
										$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");
									}
								}
							});

							}else{
							
							/*PF('msgdb').renderMessage({"summary":"",
				                "detail":val,
				                "severity":"info"});*/
								document.getElementById('unepop').innerHTML = "Warning! Please input valid data.";
						}
					});
				});
			}else{
				document.getElementById('unepop').innerHTML = "Error! Insert failed. Please input valid data.";
			}
		}else if(text=='Delete'){
			var value="edit_"+id;
			var data="Start";
			$("."+value).each(function () {
				data=data+"##"+$(this).val();
			});
			if(dbname!="" && dbname!=undefined && tablename!=""  && tablename!=undefined && data!="" && data!="Start" && data!=undefined){
				$.post("http://"+window.location.host+"/VMastsDBEX",{'command': 'delete','attr':dbname,'tablename':tablename,'data':data },function(data){

					
					$.each( data, function( key, val ) {
						if(val=="Deleted"){
							document.getElementById('unepop').innerHTML = "Values deleted successfully!";
							$.ajax({
								type:"POST",
								url:"http://"+window.location.host+"/VMastsDBEX",
								data:{'command':'selectTableValues','attr':dbname,'tablename':tablename},
								async: true,
								cache: false,
								datatype:"json",
								success:function(data){


									var obj=data;

									obj=JSON.stringify(data);
									//alert("Object value :: "+obj);
									$.each( data, function( key, val ) {
										
										if(key=="rowCount"){
											rowcount=val;					
										}
									});

									if(rowcount>2){
										$.each( data, function( key, val ) {
											if(key=="field"){
												field=val;				
											}
										});

										$("#mydb").empty();

										$("#mydb").attr('name',tablename);
										var th="<th>"+field[0]+"</th>";
										for(var k=1;k<field.length;k++){
											th=th+"<th>"+field[k]+"</th>";
										}
										$("#mydb").append("<tr style='background-color:#9EC9D4;height:30px;border-style: solid;border-width: 2px;'><th class='opt' title='Table Name' colspan="+(field.length+1)+" style='text-align: center;'>Current Table: "+tablename+"</th></tr>");
										$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");


										var td;
										var ii=1;
										$.each( data, function( key, val ) {
											for(var ii=1;ii<rowcount;ii++){
												

												if(key=="row"+ii){						
													
													td=td+"<tr id='r"+ii+"'>";
													for(var j=0;j < val.length;j++)
													{
														var len=parseInt(val[j].length);
														if(isNaN(len)){
															len=12;
														}
														td=td+"<td><input readonly type='text' class='edit_row"+ii+"' value='"+val[j]+"' size='"+len+"px' readonly='readonly' style='border:0px;height:auto;padding: 0px;'></input></td>";

													}
													td=td+"<td class='btndelete' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Delete</button></td>";
													td=td+"<td class='btn' style='display:none;width:60px;'><button type='button' class='buttonDb' id='row"+ii+"'>Edit</button></td></tr>";
													
													ii=ii+1;
												}

											}
										});

										$("#mydb").append(td);
									}else{
										
										document.getElementById('unepop').innerHTML = "Selected database table is empty!";
										$.each( data, function( key, val ) {
											if(key=="field"){
												field=val;				
											}
										});

										$("#mydb").empty();

										$("#mydb").attr('name',tablename);
										var th="<th>"+field[0]+"</th>";
										for(var k=1;k<field.length;k++){
											th=th+"<th>"+field[k]+"</th>";
										}
										$("#mydb").append("<tr style='background-color:#d3eced;height:30px;'>"+th+"</tr>");
									}
								}
							});

						}else{

							document.getElementById('unepop').innerHTML = "Warning! Please input valid data.";
						}
					});
				});

			}else{
				
				document.getElementById('unepop').innerHTML = "Error! Update failed. Please input valid data.";
			}

		}
	});



	$('#insert').click(function(){

		document.getElementById('unepop').innerHTML = "";
		if(! $('.btn').find('button').text().indexOf("Insert")>=0){
			$('.btndelete').css({'display':'none'});
			$('.btn').css({'display':'none'});
			$('.opt').css({'display':'block'});
			$('.btn').children().each(function () {
				var btnValue=$(this).attr('id');
				if($(".btn #"+btnValue).text()=='Update'){

					$(".btn #"+btnValue).text('Edit');
				}
			
				$(".edit_"+btnValue).attr("readonly", "readonly");
				$(".edit_"+btnValue).css({'background-color':'','color':'','height':'','cursor':'pointer','text-decoration':''});
			});


			var path=$('#ip1').val();
			var tablename=$("#mydb").attr('name');
			var dbname=path.substring(path.lastIndexOf("/")+1,path.length);

			if(dbname!="" && dbname!=undefined && tablename!=""  && tablename!=undefined){
					$.ajax({
					type:"POST",
					url:"http://"+window.location.host+"/VMastsDBEX",
					data:{'command':'selectTableValues','attr':dbname,'tablename':tablename},
					async: true,
					cache: false,
					datatype:"json",
					success:function(data){
						var obj=data;

						obj=JSON.stringify(data);
						$.each( data, function( key, val ) {
							if(key=="rowCount"){
								rowcount=val;					
							}
						});

						$.each( data, function( key, val ) {
							if(key=="field"){
								field=val;				
							}
						});
						var td;
						var ii=rowcount;
						var valueLast;
						td=td+"<tr id='r"+(ii)+"'>";
						for(var j=0;j < field.length;j++)
						{

							td=td+"<td><input type='text' class='edit_row"+(ii)+"' value='' size='12px' style='border:0px;height:auto;padding: 0px;'></input></td>";

						}
						td=td+"<td class='btn' style='width:60px;'><button type='button' class='buttonDb' id='row"+(ii)+"'>Insert</button></td></tr>";
						$("#mydb").append(td);
					}
				});
					
					document.getElementById('unepop').innerHTML = "Please insert data in blank input fields at the end of the table.";
			}else{
				document.getElementById('unepop').innerHTML = "Error! Update failed. Please input valid data.";
			}



		}

	});

	$('#delete').click(function(){
		document.getElementById('unepop').innerHTML = "";
		$('.btndelete').css({'display':'block'});
		$('.btn').css({'display':'none'});
		$('.opt').css({'display':'block'});

		$('.btn').children().each(function () {
			var btnValue=$(this).attr('id');

			if($(".btn #"+btnValue).text()=='Update'){

				$(".btn #"+btnValue).text('Edit');
			}

			if($(".btn #"+btnValue).text()=='Insert'){


				var i=$(".btn #"+btnValue).attr('id');
		
				i=i.replace("row",'');
		
				$("#mydb tr #r"+btnValue[btnValue.length-1]).css({'display':'none'});
				$('#r'+i).css({'display':'none'});
				$( "#r"+i).remove();
				$(".btn #"+btnValue).css({'display':'none'});
			}
		
			$(".edit_"+btnValue).attr("readonly", "readonly");
			$(".edit_"+btnValue).css({'background-color':'','color':'','height':'','cursor':'pointer','text-decoration':''});
		});
	});

	$('#update1').click(function(){
	
		document.getElementById('unepop').innerHTML = "";
		
		$('.btndelete').css({'display':'none'});
		$('.btn').css({'display':'block'});
		$('.opt').css({'display':'block'});

		$('.btn').children().each(function () {
			var btnValue=$(this).attr('id');
			

			if($(".btn #"+btnValue).text()=='Insert'){
				
				var i=$(".btn #"+btnValue).attr('id');
				
				i=i.replace("row",'');
				
				$("#mydb tr #r"+btnValue[btnValue.length-1]).css({'display':'none'});
				$( "#r"+i).css({'display':'none'});
				$( "#r"+i).remove();
				$(".btn #"+btnValue).css({'display':'none'});
			}
		});

	});

	//Push File...

	$('#push').click(function(event){
	
		document.getElementById('unepop').innerHTML = "";
		
		var d=$('#ip1').val();
		var s=$('#showdbname').text();
		var desc=d;
		
		if($('#status').attr('title')==('Connected')){
			
			$.post("http://"+window.location.host+"/VMastsPH",{'desc': desc,'filename':s },function(data){
				var obj=$.parseJSON(data);
			
				$.each(obj, function( key, val ) {
					
					document.getElementById('unepop').innerHTML = val;
				});
				
			});

		}else{
			
			document.getElementById('unepop').innerHTML = "Connection unavailable! Please make sure your device is connected.";
		}

	});

});

function vali()
{
	$('#overlay').fadeIn('fast',function(){
		$('#box').show();
		$('#box').animate({'top':'35%'},500);
	});
}
function valiCloseDB(){
	
	$('#overlay').fadeOut('fast',function(){
    $('#box').hide();
    });
}

function count3(){
	$('#s_timer3').countdowntimer({
    seconds :30,
    size : "lg"
});
}